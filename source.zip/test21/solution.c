#include <stdio.h>
#include <malloc.h>

#undef  offsetof
#define offsetof(TYPE, MEMBER)	((size_t)&((TYPE *)0)->MEMBER)

#define container_of(ptr, type, member) ({			\
		const typeof( ((type *)0)->member ) *__mptr = (ptr);	\
		(type *)( (char *)__mptr - offsetof(type,member) );})

#define list_entry(ptr, type, member) \
	container_of(ptr, type, member)

#define list_first_entry(ptr, type, member) \
	list_entry((ptr)->next, type, member)

#define list_for_each(pos, head) \
	for (pos = (head)->next; pos != (head); pos = pos->next)

#define list_for_each_entry(pos, head, member)				\
	for (pos = list_first_entry(head, typeof(*pos), member);	\
			&pos->member != (head);					\
			pos = list_next_entry(pos, member))

#define list_for_each_safe(pos, n, head) \
	for (pos = (head)->next, n = pos->next; pos != (head); \
		pos = n, n = pos->next)

struct list_head {
	struct list_head *next, *prev;
};

void __list_add(struct list_head *new,
		struct list_head *prev,
		struct list_head *next)
{
	next->prev = new;
	new->next = next;
	new->prev = prev;
	prev->next = new;
}

void list_add(struct list_head *new, struct list_head *head)
{
	__list_add(new, head, head->next);
}

void list_add_tail(struct list_head *new, struct list_head *head)
{
	__list_add(new, head->prev, head);
}

void __list_del(struct list_head * prev, struct list_head * next)
{
	next->prev = prev;
	prev->next = next;
}

void list_del(struct list_head *entry)
{
	__list_del(entry->prev, entry->next);
}

int list_empty(const struct list_head *head)
{
	return head->next == head;
}

void INIT_LIST_HEAD(struct list_head *list)
{
	list->next = list;
	list->prev = list;
}
//-------------------------------------------------------------------------------
char * my_strcpy(char * dest,char *src)
{
	char *tmp = dest;

	while ((*dest++ = *src++) != '\0')
		/* nothing */;
	return tmp;
}

size_t my_strlen(const char *s)
{
	const char *sc;

	for (sc = s; *sc != '\0'; ++sc)
		/* nothing */;
	return sc - s;
}
//-----------------------------------------------------------------------

typedef struct
{
	char word[10];
	struct list_head list;
} WORD;

struct list_head word_list;

void init(void)
{
	INIT_LIST_HEAD(&word_list);
}

void display(void)
{
	struct list_head *temp;
	WORD *w;

	printf("head");
	list_for_each(temp, &word_list)
	{
		w = list_entry(temp, WORD, list);
		printf("->[%s]", w->word);
	}
	printf("\n");
}

void addWord( char str[] )
{
	WORD *w;

	w = malloc( sizeof(WORD) ); 
	my_strcpy(w->word, str );
	list_add_tail( &w->list, &word_list );
}

int match( char word[], int w, char str[], int s)
{
	int word_len;
	int str_len;

	word_len = my_strlen(word);
	str_len = my_strlen(str);

	if( w < word_len && s < str_len && word[w] == str[s] )
		return match( word, w+1, str, s+1);

	if( w == word_len && s == str_len )
		return 1;

	if( str[s] == '*' )
		if( match(word, w, str, s+1) || (w < word_len && match(word, w+1, str, s)) )
			return 1;
	
	return 0;
}

int removeWord( char str[] )
{
	int count = 0;
	struct list_head *temp, *n;

	WORD *w;

	list_for_each_safe(temp, n, &word_list)
	{
		w = list_entry(temp, WORD, list);
		if( match( w->word, 0, str, 0 ) )
		{
			list_del( temp );
			count++;
		}
	}
	return count;
}


int searchWord( char str[] )
{
	int count = 0;
	struct list_head *temp;

	WORD *w;

	list_for_each(temp, &word_list)
	{
		w = list_entry(temp, WORD, list);
		if( match( w->word, 0, str, 0 ) )
		{
			count++;
		}
	}
	return count;
}

int main()
{
	int ret;

	init();
	
	addWord("frog");
	addWord("flag");
	addWord("flag");
	addWord("play");

	ret = searchWord("fl*g");
	printf("ret=%d\n", ret );
	
	ret = searchWord("f*g");
	printf("ret=%d\n", ret );

	ret = removeWord("flag");
	printf("ret=%d\n", ret );

	ret = searchWord("flag");
	printf("ret=%d\n", ret );

	addWord("slay");
	addWord("slayer");
	addWord("slave");

	ret = searchWord("slay*");
	printf("ret=%d\n", ret );

	ret = removeWord("*lay");
	printf("ret=%d\n", ret );

	ret = searchWord("s*");
	printf("ret=%d\n", ret );

	ret = searchWord("*");
	printf("ret=%d\n", ret );

	ret = removeWord("*");
	printf("ret=%d\n", ret );

	ret = searchWord("*");
	printf("ret=%d\n", ret );

	display();

	return 0;
}











