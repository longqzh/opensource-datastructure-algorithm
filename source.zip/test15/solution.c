#include <stdio.h>
#include <malloc.h>

#undef  offsetof
#define offsetof(TYPE, MEMBER)	((size_t)&((TYPE *)0)->MEMBER)

#define container_of(ptr, type, member) ({			\
		const typeof( ((type *)0)->member ) *__mptr = (ptr);	\
		(type *)( (char *)__mptr - offsetof(type,member) );})

#define list_entry(ptr, type, member) \
	container_of(ptr, type, member)

#define list_first_entry(ptr, type, member) \
	list_entry((ptr)->next, type, member)

#define list_for_each(pos, head) \
	for (pos = (head)->next; pos != (head); pos = pos->next)

#define list_for_each_entry(pos, head, member)				\
	for (pos = list_first_entry(head, typeof(*pos), member);	\
			&pos->member != (head);					\
			pos = list_next_entry(pos, member))

#define list_for_each_safe(pos, n, head) \
	for (pos = (head)->next, n = pos->next; pos != (head); \
		pos = n, n = pos->next)

struct list_head {
	struct list_head *next, *prev;
};

void __list_add(struct list_head *new,
		struct list_head *prev,
		struct list_head *next)
{
	next->prev = new;
	new->next = next;
	new->prev = prev;
	prev->next = new;
}

void list_add(struct list_head *new, struct list_head *head)
{
	__list_add(new, head, head->next);
}

void list_add_tail(struct list_head *new, struct list_head *head)
{
	__list_add(new, head->prev, head);
}

void __list_del(struct list_head * prev, struct list_head * next)
{
	next->prev = prev;
	prev->next = next;
}

void list_del(struct list_head *entry)
{
	__list_del(entry->prev, entry->next);
}

int list_empty(const struct list_head *head)
{
	return head->next == head;
}

void INIT_LIST_HEAD(struct list_head *list)
{
	list->next = list;
	list->prev = list;
}
//-------------------------------------------------------------------------------
int my_strcmp(const char *cs, const char *ct)
{
	unsigned char c1, c2;

	while (1) {
		c1 = *cs++;
		c2 = *ct++;
		if (c1 != c2)
			return c1 < c2 ? -1 : 1;
		if (!c1)
			break;
	}
	return 0;
}

int my_strncmp(char * cs, char * ct, int count)
{
	char res = 0;

	while (count) {
		if ((res = *cs - *ct++) != 0 || !*cs++)
			break;
		count--;
	}

	return res;
}

char *my_strncpy(char *dest, const char *src, size_t count)
{
	char *tmp = dest;

	while (count) {
		if ((*tmp = *src) != 0)
			src++;
		tmp++;
		count--;
	}
	return dest;
}

char * my_strcpy(char * dest,char *src)
{
	char *tmp = dest;

	while ((*dest++ = *src++) != '\0')
		/* nothing */;
	return tmp;
}

char * my_strchr(const char * s, int c)
{
	for(; *s != (char) c; ++s)
		if (*s == '\0')
			return NULL;
	return (char *) s;
}

char *my_strpbrk(const char *cs, const char *ct)
{
	const char *sc1, *sc2;

	for (sc1 = cs; *sc1 != '\0'; ++sc1) {
		for (sc2 = ct; *sc2 != '\0'; ++sc2) {
			if (*sc1 == *sc2)
				return (char *)sc1;
		}
	}
	return NULL;
}

char *my_strsep(char **s, const char *ct)
{
	char *sbegin = *s;
	char *end;

	if (sbegin == NULL)
		return NULL;

	end = my_strpbrk(sbegin, ct);
	if (end)
		*end++ = '\0';
	*s = end;
	return sbegin;
}
//-----------------------------------------------------------------------

typedef struct
{
	int gid;
	struct list_head event_list_head;
} GROUP;

typedef struct
{
	int uid;
	char ename[200];
	struct list_head event_list;
	struct list_head list;
} EVENT;

GROUP *group_table;

int group_count;

void init(int N)
{
	int i;

	group_count = N;

	group_table = calloc(N, sizeof(GROUP));

	for(i=0; i<group_count; i++ )
	{
		group_table[i].gid = i+1;
		INIT_LIST_HEAD(&group_table[i].event_list_head);
	}
}

void display(void)
{
	int i, j;
	struct list_head *temp1;
	struct list_head *temp2;
	EVENT *master, *member;

	for(i=0; i<group_count; i++ )
	{
		printf("gid=%d\n", group_table[i].gid);
		list_for_each(temp1, &group_table[i].event_list_head)
		{
			master = list_entry(temp1, EVENT, list);
			printf("master[%d, %s]", master->uid, master->ename);
			list_for_each(temp2, &master->event_list)
			{
				member = list_entry(temp2, EVENT, list);
				printf("->[%d, %s]", member->uid, member->ename);
			}
			printf("\n");
		}
		printf("\n\n");
	}
}

void addEvent( int uid, char ename[], int groupid)
{
	struct list_head *temp1;
	struct list_head *temp2;

	EVENT *event, *master;

	int flag=0;

	event = calloc(1, sizeof(EVENT));
	event->uid = uid;
	my_strcpy( event->ename, ename );
	INIT_LIST_HEAD(&event->event_list);

	list_for_each(temp1, &group_table[groupid-1].event_list_head)
	{
		master = list_entry(temp1, EVENT, list);
		if( my_strcmp( ename, master->ename ) == 0 )
		{
			flag=1;
			break;
		}
	}

	if( flag == 1 )
	{
		list_add_tail( &event->list, &master->event_list );
	}
	else
	{
		list_add_tail( &event->list, &group_table[groupid-1].event_list_head );
	}
}

int getCount(int uid)
{
	int count=0;
	int i, j;
	struct list_head *temp1;
	struct list_head *temp2;
	EVENT *master, *member;

	for(i=0; i<group_count; i++ )
	{
		list_for_each(temp1, &group_table[i].event_list_head)
		{
			master = list_entry(temp1, EVENT, list);
			if( master->uid == uid )
				count++;
			list_for_each(temp2, &master->event_list)
			{
				member = list_entry(temp2, EVENT, list);
				if( member->uid == uid )
					count++;
			}
		}
	}
	return count;
}

int deleteEvent(int uid, char ename[])
{
	int count=0;
	int i, j;
	struct list_head *temp1;
	struct list_head *temp2;
	struct list_head *n1;
	struct list_head *n2;
	EVENT *master, *member;

	for(i=0; i<group_count; i++ )
	{
		list_for_each_safe(temp1, n1, &group_table[i].event_list_head)
		{
			master = list_entry(temp1, EVENT, list);
			if( master->uid == uid && my_strcmp(master->ename, ename)==0 )
			{
				count++;
				list_for_each_safe(temp2, n2, &master->event_list)
				{
					count++;
					member = list_entry(temp2, EVENT, list);
					list_del( temp2 );
					free(member);
				}

				list_del(temp1);
				free(master);
				continue;
			}
			list_for_each_safe(temp2, n2, &master->event_list)
			{
				member = list_entry(temp2, EVENT, list);
				if( member->uid == uid && my_strcmp(member->ename, ename)==0 )
				{
					list_del(temp2);	
					free(member);
					count++;
				}
			}
		}
	}
	return count;
}

int changeEvent(int uid, char ename[], char cname[])
{
	int count=0;
	int i, j;
	struct list_head *temp1;
	struct list_head *temp2;
	struct list_head *n1;
	struct list_head *n2;
	EVENT *master, *member;

	for(i=0; i<group_count; i++ )
	{
		list_for_each_safe(temp1, n1, &group_table[i].event_list_head)
		{
			master = list_entry(temp1, EVENT, list);
			if( master->uid == uid && my_strcmp(master->ename, ename)==0 )
			{
				my_strcpy( master->ename, cname );
				count++; 

				list_for_each_safe(temp2, n2, &master->event_list)
				{
					count++;
					member = list_entry(temp2, EVENT, list);
					my_strcpy( member->ename, cname );
				}
				continue;
			}
			list_for_each_safe(temp2, n2, &master->event_list)
			{
				member = list_entry(temp2, EVENT, list);
				if( member->uid == uid && my_strcmp(member->ename, ename)==0 )
				{
					list_del(temp2);	
					list_add_tail(temp2, &group_table[i].event_list_head);
					my_strcpy( member->ename, cname );
					count++;
				}
			}
		}
	}
	return count;
}

int main()
{
	int ret;
	init(3);
	
	addEvent(4, "abcd", 2);
	addEvent(1, "abcd", 2);
	addEvent(2, "tick", 1);
	addEvent(2, "abcd", 1);
	addEvent(3, "tick", 1);
	addEvent(4, "tick", 1);
	addEvent(5, "abcd", 3);

	display();

	ret = getCount(2);
	printf("ret=%d\n", ret );

	ret = deleteEvent(1, "abcd");
	printf("ret=%d\n", ret );

	ret = getCount(1);
	printf("ret=%d\n", ret );

	ret = deleteEvent(2, "abcd");
	printf("ret=%d\n", ret );

	display();

	ret = changeEvent(4, "tick", "fail");
	printf("ret=%d\n", ret );

	display();

	ret = getCount(4);
	printf("ret=%d\n", ret );

	ret = changeEvent(2, "tick", "quit");
	printf("ret=%d\n", ret );

	display();

	ret = deleteEvent(5, "tick");
	printf("ret=%d\n", ret );

	addEvent(5, "quit", 1);

	display();

	ret = getCount(5);
	printf("ret=%d\n", ret );

	ret = deleteEvent(5, "abcd");
	printf("ret=%d\n", ret );

	addEvent(3, "abcd", 3);

	display();

	ret = getCount(3);
	printf("ret=%d\n", ret );

	ret = changeEvent(2, "quit", "tear");
	printf("ret=%d\n", ret );

	display();

	ret = deleteEvent(2, "tear");
	printf("ret=%d\n", ret );

	display();

	return 0;
}











