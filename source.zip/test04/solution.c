#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>

#undef  offsetof
#define offsetof(TYPE, MEMBER)	((size_t)&((TYPE *)0)->MEMBER)

#define container_of(ptr, type, member) ({			\
	const typeof( ((type *)0)->member ) *__mptr = (ptr);	\
	(type *)( (char *)__mptr - offsetof(type,member) );})

#define list_entry(ptr, type, member) \
	container_of(ptr, type, member)

#define list_first_entry(ptr, type, member) \
	list_entry((ptr)->next, type, member)

#define list_for_each(pos, head) \
	for (pos = (head)->next; pos != (head); pos = pos->next)

#define list_for_each_entry(pos, head, member)				\
	for (pos = list_first_entry(head, typeof(*pos), member);	\
	     &pos->member != (head);					\
	     pos = list_next_entry(pos, member))

struct list_head {
	struct list_head *next, *prev;
};

void __list_add(struct list_head *new,
			      struct list_head *prev,
			      struct list_head *next)
{
	next->prev = new;
	new->next = next;
	new->prev = prev;
	prev->next = new;
}

void list_add(struct list_head *new, struct list_head *head)
{
	__list_add(new, head, head->next);
}

void list_add_tail(struct list_head *new, struct list_head *head)
{
	__list_add(new, head->prev, head);
}

void __list_del(struct list_head * prev, struct list_head * next)
{
	next->prev = prev;
	prev->next = next;
}

void list_del(struct list_head *entry)
{
	__list_del(entry->prev, entry->next);
}

int list_empty(const struct list_head *head)
{
	return head->next == head;
}

void INIT_LIST_HEAD(struct list_head *list)
{
	list->next = list;
	list->prev = list;
}

//-------------------------------------------------------------------------------

typedef struct
{
	int index;
	int start_process;
	struct list_head list;
} LOT;

typedef struct
{
	int index;
	int pt;
	int n_process;
	LOT *lot;
	struct list_head list;
} FACILITY;

typedef struct
{
	int lot_count;
	struct list_head facilities;
	struct list_head ready_queue;
} PROCESS;


PROCESS *process;
int lot_count;
int output_count;
int process_count;
int current_time;

void init( int N )
{
	int i;
	process_count = N;
	process = calloc(N, sizeof(PROCESS));

	for(i=0; i<N; i++)
	{
		INIT_LIST_HEAD(&process[i].facilities);
		INIT_LIST_HEAD(&process[i].ready_queue);
	}
}

void insert_fac(FACILITY *new, PROCESS *head)
{
	struct list_head *temp;
	FACILITY *f;

	list_for_each( temp, &head->facilities )
	{
		f = list_entry(temp, FACILITY, list); 
		if( f->pt > new->pt )
			break;
	}
	list_add( &new->list, temp->prev);
}

void setupTool(int T, int stepNo[5000], int procTime[5000])
{
	int i;
	FACILITY *temp;
	for(i=0; i<T; i++ )
	{
		temp = calloc(1, sizeof(FACILITY));
		temp->index = i;
		temp->n_process = stepNo[i];
		temp->pt = procTime[i];
		temp->lot = 0;
		insert_fac(temp, &process[stepNo[i]]);
	}
}


void processEnqueue( int time, int process_index, LOT *lot)
{
	FACILITY *f;
	struct list_head *temp;
	int flag=0;
	int remain;

	list_for_each(temp, &process[process_index].facilities)
	{
		f = list_entry(temp, FACILITY, list); 

		if( f->lot == 0 )
		{
			f->lot = lot;
			f->lot->start_process = time;
			flag = 1;
			break;
		}
	}
	if( flag == 0 )
	{
		list_add_tail(&lot->list, &process[process_index].ready_queue );
	}

	process[process_index].lot_count++;
}

void readyTofacility(int time, int process_index)
{
	struct list_head *temp;
	FACILITY *f;
	LOT *lot;

	list_for_each(temp, &process[process_index].facilities)
	{
		f = list_entry(temp, FACILITY, list); 
		if( f->lot == 0 )
		{
			if( !list_empty(&process[process_index].ready_queue) )
			{
				lot = list_first_entry(&process[process_index].ready_queue, LOT, list);
				list_del(&lot->list);
				lot->start_process = time;
				f->lot = lot;
			}
		}
	}
}

void updateLot(int time)
{
	int i;
	int j;
	struct list_head *temp;
	FACILITY *f;
	LOT *lot;
	int flag=0;
	int ret;
	int remain;

	for(i=process_count-1; i>=0; i--)
	{
		if( process[i].lot_count == 0 )
			continue;

		if( i == process_count-1 )
		{
			list_for_each(temp, &process[i].facilities)
			{
				f = list_entry(temp, FACILITY, list); 
				if( f->lot != 0 )
				{
                    remain = time - (f->lot->start_process + f->pt);
					if( remain >= 0 ) 
					{
						process[i].lot_count--;
						output_count++;
						free(f->lot);
						f->lot = 0;
					}
				}
			}
			readyTofacility(time, i);
		}
		else
		{
			list_for_each(temp, &process[i].facilities)
			{
				f = list_entry(temp, FACILITY, list); 
				if( f->lot != 0 )
				{
                    remain = time - (f->lot->start_process + f->pt);
					if( remain >= 0 ) 
					{
						lot = f->lot;
						f->lot = 0;
						process[i].lot_count--;
						processEnqueue( time, i+1, lot);

					}
				}
			}
			readyTofacility(time, i);
		}
	}
}

void addLot(int time, int number)
{
	int i;
	LOT *lot;
	struct list_head *temp;
	FACILITY *f;
	int flag=0;

	for(i=current_time+1; i<=time; i++ )
    	updateLot(i);

	for(i=0; i<number; i++ )
	{
	    lot = calloc(1, sizeof(LOT));	
		lot->index = lot_count++;
		processEnqueue(time, 0, lot);
	}
	current_time = time;
}

int simulate(int time, int wip[])
{
	int i;
	for(i=current_time+1; i<=time; i++ )
    	updateLot(i);


	for(i=0; i<process_count; i++)
		wip[i] = process[i].lot_count;

	current_time = time;
	return output_count;
}

void display()
{
	int i;
	struct list_head *temp;
	FACILITY *f;
	LOT *lot;

	//system("clear");
	for(i=0; i<3; i++ )
	{
		printf("공정 %d : lot_count=%d\n", i, process[i].lot_count);
		printf("\tReady : ");
		list_for_each( temp, &process[i].ready_queue )
		{
			lot = list_entry(temp, LOT, list); 
			printf("->Lot%d", lot->index );
		}
		printf("\n");

		list_for_each( temp, &process[i].facilities )
		{
			f = list_entry(temp, FACILITY, list); 
			printf("\t설비%d : pt=%d ", f->index, f->pt );
			if( f->lot != 0 )
				printf("Lot%d", f->lot->index ); 
			printf("\n");
		}
	}
	//getchar();
}
void display_wip(int out, int *wip)
{
	int i;
	printf("wip : ");
	for(i=0; i<process_count; i++ )
		printf("%2d", wip[i] );
	printf("\nout : %d\n", out );
}
int main()
{
	int stepNo[] = {0,2,1,1,0,2};
	int procTime[] = {50,60,60,40,70,60};
	int wip[1024];
	int out;

	init(3);
	setupTool(6, stepNo, procTime );
	addLot(0, 3);
	out = simulate(70, wip);
	display_wip( out, wip);
	addLot(90, 3);
	out = simulate(100, wip);
	display_wip( out, wip);
	out = simulate(140, wip);
	display_wip( out, wip);
	out = simulate(150, wip);
	display_wip( out, wip);
	display();

	return 0;
}
