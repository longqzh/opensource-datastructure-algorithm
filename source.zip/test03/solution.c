#include <stdio.h>

typedef struct
{
	int x;
	int y;
} Result;

#define N  15
#define M  5

int map[][N] = 
{
	{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
	{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
	{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
	{1,1,0,0,0,0,0,0,0,0,0,0,0,1,1},
	{0,1,0,1,0,0,0,0,0,0,1,0,0,0,0},
	{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
	{0,0,0,0,1,0,0,0,0,0,1,0,1,0,1},
	{0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
	{0,0,0,0,1,1,0,1,0,0,0,0,0,0,0},
	{0,0,0,0,1,0,1,1,1,0,0,0,0,0,0},
	{0,0,0,0,1,1,1,0,0,0,1,0,1,0,1},
	{0,0,0,1,0,0,0,0,0,0,0,0,1,0,1},
	{0,0,0,0,0,0,0,0,0,0,1,1,0,0,1},
	{0,0,0,0,0,0,0,0,0,0,1,0,0,0,0},
	{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}
};

void init(int _N, int _M, int _Map[][N])
{
}

int star_check( int star[][M], int count, int map_x, int map_y, Result *result, int angle)
{
	int i;
	int j;
	int row;
	int col;

	for(i=0; i<M; i++)
	{
		for(j=0; j<M; j++)
		{
			switch(angle)
			{
				case   0: row=i; col=j; break;
				case  90: row=j; col=M-i-1; break;
				case 180: row=M-i-1; col=M-j-1; break;
				case 270: row=M-j-1; col=i; break;
			}

			if( star[row][col] > 0 && map[map_y+i][map_x+j]>0 )
			{
				count--;
				if( star[row][col] == 9 )
				{
					result->y = map_y+i;
					result->x = map_x+j;
				}

				if( count == 0 )
				{
					return 1;
				}
			}
		}
	}
	return 0;
}

Result fineConstellation(int stars[][M])
{
	int i,j,k;
	int count=0; 
	int ret;
	Result result={0,};
	int angles[] = {0,90,180,270};

	for(i=0; i<M; i++ )
		for(j=0; j<M; j++ )
			if( stars[i][j] > 0 )
				count++;

	for(i=0; i<N-M+1; i++ )
	{
		for(j=0; j<N-M+1; j++ )
		{
			for(k=0; k<4; k++)
			{
				ret = star_check( stars, count, j, i, &result, angles[k] );
				if( ret == 1 ) 
					return result;
			}
		}
	}
	return result;
}

int main()
{
	Result result;
	int i;
	int stars[][M][M] = 
	{
		{
			{0,0,1,0,1},
			{0,1,1,0,0},
			{0,0,0,0,0},
			{0,9,0,0,0},
			{0,0,0,0,0}
		},
		{
			{0,0,0,0,1},
			{0,1,1,1,0},
			{0,0,0,0,0},
			{9,0,0,1,0},
			{0,0,0,0,0}
		},
		{
			{1,1,0,1,0},
			{0,1,0,0,0},
			{0,0,9,1,0},
			{0,0,0,0,0},
			{0,1,1,1,0}
		},
		{
			{0,0,0,0,1},
			{0,0,0,0,9},
			{0,0,0,0,1},
			{0,0,0,1,0},
			{0,1,0,0,1}
		},
		{
			{0,1,0,1,0},
			{0,0,0,0,0},
			{0,1,0,0,0},
			{0,0,0,0,1},
			{9,1,0,0,1}
		}
	};

	for(i=0; i<5; i++)
	{
		result.x=0; 
		result.y=0;
		result = fineConstellation(stars[i]);
		printf("result.y=%2d, result.x=%2d\n", result.y, result.x);
	}

	return 0;
}
