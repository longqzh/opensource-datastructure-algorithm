#include <stdio.h>
#include <malloc.h>

#undef  offsetof
#define offsetof(TYPE, MEMBER)	((size_t)&((TYPE *)0)->MEMBER)

#define container_of(ptr, type, member) ({			\
		const typeof( ((type *)0)->member ) *__mptr = (ptr);	\
		(type *)( (char *)__mptr - offsetof(type,member) );})

#define list_entry(ptr, type, member) \
	container_of(ptr, type, member)

#define list_first_entry(ptr, type, member) \
	list_entry((ptr)->next, type, member)

#define list_for_each(pos, head) \
	for (pos = (head)->next; pos != (head); pos = pos->next)

#define list_for_each_entry(pos, head, member)				\
	for (pos = list_first_entry(head, typeof(*pos), member);	\
			&pos->member != (head);					\
			pos = list_next_entry(pos, member))

#define list_for_each_safe(pos, n, head) \
	for (pos = (head)->next, n = pos->next; pos != (head); \
		pos = n, n = pos->next)

struct list_head {
	struct list_head *next, *prev;
};

void __list_add(struct list_head *new,
		struct list_head *prev,
		struct list_head *next)
{
	next->prev = new;
	new->next = next;
	new->prev = prev;
	prev->next = new;
}

void list_add(struct list_head *new, struct list_head *head)
{
	__list_add(new, head, head->next);
}

void list_add_tail(struct list_head *new, struct list_head *head)
{
	__list_add(new, head->prev, head);
}

void __list_del(struct list_head * prev, struct list_head * next)
{
	next->prev = prev;
	prev->next = next;
}

void list_del(struct list_head *entry)
{
	__list_del(entry->prev, entry->next);
}

int list_empty(const struct list_head *head)
{
	return head->next == head;
}

void INIT_LIST_HEAD(struct list_head *list)
{
	list->next = list;
	list->prev = list;
}
//-------------------------------------------------------------------------------
int my_strcmp(const char *cs, const char *ct)
{
	unsigned char c1, c2;

	while (1) {
		c1 = *cs++;
		c2 = *ct++;
		if (c1 != c2)
			return c1 < c2 ? -1 : 1;
		if (!c1)
			break;
	}
	return 0;
}

int my_strncmp(char * cs, char * ct, int count)
{
	char res = 0;

	while (count) {
		if ((res = *cs - *ct++) != 0 || !*cs++)
			break;
		count--;
	}

	return res;
}

char *my_strncpy(char *dest, const char *src, size_t count)
{
	char *tmp = dest;

	while (count) {
		if ((*tmp = *src) != 0)
			src++;
		tmp++;
		count--;
	}
	return dest;
}

char * my_strcpy(char * dest,char *src)
{
	char *tmp = dest;

	while ((*dest++ = *src++) != '\0')
		/* nothing */;
	return tmp;
}

char * my_strchr(const char * s, int c)
{
	for(; *s != (char) c; ++s)
		if (*s == '\0')
			return NULL;
	return (char *) s;
}

char *my_strpbrk(const char *cs, const char *ct)
{
	const char *sc1, *sc2;

	for (sc1 = cs; *sc1 != '\0'; ++sc1) {
		for (sc2 = ct; *sc2 != '\0'; ++sc2) {
			if (*sc1 == *sc2)
				return (char *)sc1;
		}
	}
	return NULL;
}

char *my_strsep(char **s, const char *ct)
{
	char *sbegin = *s;
	char *end;

	if (sbegin == NULL)
		return NULL;

	end = my_strpbrk(sbegin, ct);
	if (end)
		*end++ = '\0';
	*s = end;
	return sbegin;
}
//-----------------------------------------------------------------------


typedef struct member
{
	int  id;
	char name[20];
	int  sex;
	struct member *mother;
	struct member *father;
	struct member *wife;
	struct member *husband;
	struct list_head child;
	struct list_head list;
} MEMBER;

typedef struct
{
	MEMBER *p;
	struct list_head list;
} CHILD;

struct list_head member_list;
int member_count;

#define  INF  1000000
#define  SIZE 200 
int map[SIZE][SIZE] = {0,};
int cacheDistance;

MEMBER* allocMember()
{
	MEMBER *p;
	p = calloc(1, sizeof(MEMBER));
	return p;
}

void initMember (MEMBER *p, char name[], int sex)
{
	my_strcpy(p->name, name);
	p->sex = sex;
	INIT_LIST_HEAD(&p->child);
	p->id = member_count++;
	list_add_tail( &p->list, &member_list );
}

MEMBER* findMemberByName( char name[] )
{
	struct list_head *temp;
	MEMBER *p;

	list_for_each( temp, &member_list )
	{
		p = list_entry( temp, MEMBER, list );
		if( my_strcmp( p->name, name )==0 )
			return p;
	}
	return 0;
}

MEMBER* findMemberByID( int id )
{
	struct list_head *temp;
	MEMBER *p;

	list_for_each( temp, &member_list )
	{
		p = list_entry( temp, MEMBER, list );
		if( p->id == id )
			return p;
	}
	return 0;
}

void init( char name[], int sex)
{
	MEMBER *p;

	INIT_LIST_HEAD(&member_list);

	p = allocMember();
	initMember( p, name, sex );
}

int addMember(char newMemberName[], int newMemberSex, int relationship, char existingMemberName[])
{
	MEMBER *p;
	MEMBER *newMember;
	struct list_head *temp;

	if( findMemberByName( newMemberName ) )
	{
		printf("이미 멤버 등록됨\n");
		return 0;
	}

	p = findMemberByName( existingMemberName );

	if( p == 0 )
	{
		printf("등록된 멤버 없음\n");
		return 0;
	}

	if( relationship == 0 )
	{
		CHILD *child, *c; 
		if( p->sex == newMemberSex ) 
		{
			printf("같은 성별은 배우자가 될수 없음\n");
			return 0;
		}
		if( newMemberSex == 0 )
		{
			if( p->husband != 0 )
			{
				printf("이미 등록된 배우자 있음\n");
				return 0;
			}
			newMember = allocMember();
            initMember(newMember, newMemberName, newMemberSex);
			newMember->wife = p;
			p->husband = newMember;
			list_for_each( temp, &p->child ) 
			{
				child = calloc(1, sizeof(CHILD) );
				c = list_entry(temp, CHILD, list ); 
				c->p->father = newMember;
				child->p = c->p; 

				list_add_tail( &child->list, &newMember->child);
			}
		}
		else if ( newMemberSex == 1 )
		{
			if( p->wife != 0 )
			{
				printf("이미 등록된 배우자 있음\n");
				return 0;
			}
			newMember = allocMember();
            initMember(newMember, newMemberName, newMemberSex);
			newMember->husband = p;
			p->wife = newMember;
			list_for_each( temp, &p->child ) 
			{
				child = calloc(1, sizeof(CHILD) );
				c = list_entry(temp, CHILD, list ); 
				c->p->mother = newMember;
				child->p = c->p; 

				list_add_tail( &child->list, &newMember->child);
			}
		}
	}
	else if( relationship == 1 )
	{
		CHILD *child, *c; 
		if( newMemberSex == 0 )
		{
			if( p->father != 0 )
			{
				printf("이미 등록된 부모 있음\n");
				return 0;
			}
			newMember = allocMember();
            initMember(newMember, newMemberName, newMemberSex);
			p->father = newMember;

			if( p->mother == 0 ) 
			{
				child = calloc(1, sizeof(CHILD) );
				child->p = p;
				list_add_tail( &child->list, &newMember->child);
			}
			else if( p->mother != 0 ) 
			{
				p->mother->husband = newMember;
				p->father->wife    = p->mother;

				list_for_each( temp, &p->mother->child ) 
				{
					c = list_entry(temp, CHILD, list ); 

					child = calloc(1, sizeof(CHILD) );
					child->p = c->p; 

					c->p->father = newMember;
					list_add_tail( &child->list, &newMember->child);
				}
			}
		}
		else if ( newMemberSex == 1 )
		{
			if( p->mother != 0 )
			{
				printf("이미 등록된 부모 있음\n");
				return 0;
			}
			newMember = allocMember();
            initMember(newMember, newMemberName, newMemberSex);
			p->mother = newMember;

			if( p->father == 0 ) 
			{
				child = calloc(1, sizeof(CHILD) );
				child->p = p;
				list_add_tail( &child->list, &newMember->child);
			}
			else if( p->father != 0 ) 
			{
				p->father->wife    = newMember;
				p->mother->husband = p->father;

				list_for_each( temp, &p->father->child ) 
				{
					c = list_entry(temp, CHILD, list ); 

					child = calloc(1, sizeof(CHILD) );
					child->p = c->p; 

					c->p->mother = newMember;
					list_add_tail( &child->list, &newMember->child);
				}
			}
		}
	}
	else if( relationship == 2 )
	{
		CHILD *child; 

		if( p->sex == 0 )
		{
			newMember = allocMember();
            initMember(newMember, newMemberName, newMemberSex);

			newMember->father = p;

			child = calloc(1, sizeof(CHILD) );
			child->p = newMember;

			list_add_tail( &child->list, &p->child);

			if( p->wife != 0 ) 
			{
				newMember->mother = p->wife;

				child = calloc(1, sizeof(CHILD) );
				child->p = newMember;

				list_add_tail( &child->list, &p->wife->child);
			}
		}
		else if ( p->sex == 1 )
		{
			newMember = allocMember();
            initMember(newMember, newMemberName, newMemberSex);

			newMember->mother = p;

			child = calloc(1, sizeof(CHILD) );
			child->p = newMember;

			list_add_tail( &child->list, &p->child);

			if( p->husband != 0 ) 
			{
				newMember->father = p->husband;

				child = calloc(1, sizeof(CHILD) );
				child->p = newMember;

				list_add_tail( &child->list, &p->husband->child);
			}
		}
	}

	cacheDistance = 0;
	return 1;
}


void floyd_warshall()
{
	int i,j,k;
	for (i = 0; i < member_count; i++)  
	{
		for (j = 0; j < member_count; j++) 
		{
			if (i == j) 
				continue;	
			for (k = 0; k < member_count; k++) 
			{				
				if (j != k && map[j][i] + map[i][k] < map[j][k])
					map[j][k] = map[j][i] + map[i][k];				
			}
		}
	}
}

int calcDistance()
{
	struct list_head *temp, *c_temp;
	CHILD *c;
	MEMBER *p;
	int id;
	int i;
	int j;

	for(i=0; i<member_count; i++ )
		for(j=0; j<member_count; j++ )
			map[i][j] = INF;

	
	list_for_each( temp, &member_list )
	{
    	p = list_entry(temp, MEMBER, list);
		map[p->id][p->id] = 0;
		map[p->id][p->id] = 0;

		if( p->sex == 0 && p->wife )
			map[p->id][p->wife->id] = 0;

		if( p->sex == 1 && p->husband )
			map[p->id][p->husband->id] = 0;

		if( p->father )
			map[p->id][p->father->id] = 1;

		if( p->mother )
			map[p->id][p->mother->id] = 1;

		list_for_each( c_temp, &p->child )
		{
			c = list_entry( c_temp, CHILD, list );
			map[p->id][c->p->id] = 1;
		}
	}
    floyd_warshall();

	/*
	for(i=0; i<member_count; i++ )
	{
		for(j=0; j<member_count; j++ )
		{
			if( map[i][j] == INF )
				printf("%4s", "INF");
			else
				printf("%4d", map[i][j]);
		}
		printf("\n");
	}
	*/

	cacheDistance = 1;
}

int getDistance( char start[], char end[] )
{
	int ret;
	int si, ei;
	if( cacheDistance == 0 )
		calcDistance();

	si = findMemberByName( start )->id; 
	ei = findMemberByName( end )->id; 
	ret = map[si][ei];
}

int countMember( char name[], int n )
{
	int count=0;
	int i, si;
	if( cacheDistance == 0 )
		calcDistance();

	si = findMemberByName( name )->id; 
	for(i=0; i<member_count; i++ )
	{
		if( si != i && map[si][i]==n ) 
			count++;
	}
	return count;
}

void display()
{
	struct list_head *temp;
	struct list_head *c_temp;
	MEMBER *p;
	CHILD *cp;

	list_for_each(temp, &member_list)
	{
		p = list_entry( temp, MEMBER, list );
		printf("id=%d, name=%s, sex=%d\n", p->id, p->name, p->sex );
		if( p->father )   printf("father=%s\n", p->father->name );
		if( p->mother )   printf("mother=%s\n", p->mother->name );
		if( p->wife )     printf("wife=%s\n", p->wife->name );
		if( p->husband )  printf("husband=%s\n", p->husband->name );
		printf("child");
		list_for_each(c_temp, &p->child)
		{
			cp = list_entry( c_temp, CHILD, list );
			printf("->[%s]", cp->p->name );
		}
		printf("\n\n");
	}
}

int main()
{
	int ret;
	init("sam", 0);
	
	ret = addMember("smith", 0, 2, "sam");
	printf("ret=%d\n", ret );

	ret = addMember("chris", 0, 2, "sam");
	printf("ret=%d\n", ret );

	ret = addMember("alice", 1, 1, "chris");
	printf("ret=%d\n", ret );

	ret = addMember("julia", 1, 1, "alice");
	printf("ret=%d\n", ret );

	ret = addMember("mas", 0, 2, "julia");
	printf("ret=%d\n", ret );

	ret = addMember("tony", 0, 0, "alice");
	printf("ret=%d\n", ret );

	ret = addMember("mak", 0, 1, "smith");
	printf("ret=%d\n", ret );

	ret = addMember("rainy", 1, 1, "smith");
	printf("ret=%d\n", ret );

	ret = addMember("dandy", 0, 0, "julia");
	printf("ret=%d\n", ret );

	ret = getDistance("sam", "chris");
	printf("ret=%d\n", ret );

    ret = getDistance("sam", "dandy");
	printf("ret=%d\n", ret );

	ret = getDistance("smith", "alice");
	printf("ret=%d\n", ret );
	
	ret = getDistance("mas", "sam");
	printf("ret=%d\n", ret );

	ret = getDistance("alice", "sam");
	printf("ret=%d\n", ret );

	ret = addMember("joon", 0, 2, "dandy");
	printf("ret=%d\n", ret );

	ret = addMember("frank", 0, 0, "joon");
	printf("ret=%d\n", ret );

	ret = addMember("anne", 1, 0, "joon");
	printf("ret=%d\n", ret );
	
	ret = addMember("david", 0, 2, "anne");
	printf("ret=%d\n", ret );

	ret = addMember("munk", 0, 1, "david");
	printf("ret=%d\n", ret );

	ret = addMember("john", 0, 1, "alice");
	printf("ret=%d\n", ret );

	display();

	ret = getDistance("david", "smith");
	printf("ret=%d\n", ret );

	ret = countMember("sam", 0);
	printf("ret=%d\n", ret );

	ret = countMember("sam", 1);
	printf("ret=%d\n", ret );

	ret = countMember("sam", 2);
	printf("ret=%d\n", ret );

	ret = countMember("sam", 3);
	printf("ret=%d\n", ret );
	
	ret = countMember("sam", 4);
	printf("ret=%d\n", ret );


	ret = getDistance("david", "smith");
	printf("ret=%d\n", ret );

	ret = countMember("alice", 1);
	printf("ret=%d\n", ret );

	ret = countMember("julia", 2);
	printf("ret=%d\n", ret );
	return 0;
}
