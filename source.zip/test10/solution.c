#include <stdio.h>
#include <malloc.h>

//-------------------------------------------------------------------------------
int my_strcmp(const char *cs, const char *ct)
{
	unsigned char c1, c2;

	while (1) {
		c1 = *cs++;
		c2 = *ct++;
		if (c1 != c2)
			return c1 < c2 ? -1 : 1;
		if (!c1)
			break;
	}
	return 0;
}

int my_strncmp(char * cs, char * ct, int count)
{
	char res = 0;

	while (count) {
		if ((res = *cs - *ct++) != 0 || !*cs++)
			break;
		count--;
	}

	return res;
}

char *my_strncpy(char *dest, const char *src, size_t count)
{
	char *tmp = dest;

	while (count) {
		if ((*tmp = *src) != 0)
			src++;
		tmp++;
		count--;
	}
	return dest;
}

char * my_strcpy(char * dest,char *src)
{
	char *tmp = dest;

	while ((*dest++ = *src++) != '\0')
		/* nothing */;
	return tmp;
}

char * my_strchr(const char * s, int c)
{
	for(; *s != (char) c; ++s)
		if (*s == '\0')
			return NULL;
	return (char *) s;
}

char *my_strpbrk(const char *cs, const char *ct)
{
	const char *sc1, *sc2;

	for (sc1 = cs; *sc1 != '\0'; ++sc1) {
		for (sc2 = ct; *sc2 != '\0'; ++sc2) {
			if (*sc1 == *sc2)
				return (char *)sc1;
		}
	}
	return NULL;
}

char *my_strsep(char **s, const char *ct)
{
	char *sbegin = *s;
	char *end;

	if (sbegin == NULL)
		return NULL;

	end = my_strpbrk(sbegin, ct);
	if (end)
		*end++ = '\0';
	*s = end;
	return sbegin;
}

size_t my_strlen(const char *s)
{
	const char *sc;

	for (sc = s; *sc != '\0'; ++sc)
		/* nothing */;
	return sc - s;
}
//-----------------------------------------------------------------------

char *origin_string;
int origin_len;

void init(int N, char init_string[] )
{
	origin_string = malloc( my_strlen(init_string) + 1 );
	my_strcpy( origin_string, init_string);
	origin_len = N;
}

int change(char string_A[], char string_B[])
{
	int A_len, B_len;
	int n=0;
	int change_count=0;
	char *start, *end;

	A_len = my_strlen(string_A);
	B_len = my_strlen(string_B);

	start = origin_string;
	while(1)
	{
		if( my_strncmp( start, string_A, A_len) == 0 ) 
		{
			change_count++;
			my_strncpy( start, string_B, B_len );
			start += A_len;
			n += A_len;
		}
		else
		{
			start++;
			n++;
		}

		if( n >= origin_len-A_len+1 )
			break;
	}
	return change_count;
}

void result(char ret[])
{
	my_strcpy( ret, origin_string );
}

int main()
{
	int ret;
	char ret_str[200];
	init(10, "baaabbbbbb");
	ret = change("baa", "aba");
	printf("ret=%d\n", ret );
	ret = change("aaa", "bba");
	printf("ret=%d\n", ret );
	ret = change("bbb", "abb");
	printf("ret=%d\n", ret );
	result(ret_str);
	printf("%s\n", ret_str );

	return 0;
}
