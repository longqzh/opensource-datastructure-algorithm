#include <stdio.h>
#include <malloc.h>

#undef  offsetof
#define offsetof(TYPE, MEMBER)	((size_t)&((TYPE *)0)->MEMBER)

#define container_of(ptr, type, member) ({			\
		const typeof( ((type *)0)->member ) *__mptr = (ptr);	\
		(type *)( (char *)__mptr - offsetof(type,member) );})

#define list_entry(ptr, type, member) \
	container_of(ptr, type, member)

#define list_first_entry(ptr, type, member) \
	list_entry((ptr)->next, type, member)

#define list_for_each(pos, head) \
	for (pos = (head)->next; pos != (head); pos = pos->next)

#define list_for_each_entry(pos, head, member)				\
	for (pos = list_first_entry(head, typeof(*pos), member);	\
			&pos->member != (head);					\
			pos = list_next_entry(pos, member))

#define list_for_each_safe(pos, n, head) \
	for (pos = (head)->next, n = pos->next; pos != (head); \
		pos = n, n = pos->next)

struct list_head {
	struct list_head *next, *prev;
};

void __list_add(struct list_head *new,
		struct list_head *prev,
		struct list_head *next)
{
	next->prev = new;
	new->next = next;
	new->prev = prev;
	prev->next = new;
}

void list_add(struct list_head *new, struct list_head *head)
{
	__list_add(new, head, head->next);
}

void list_add_tail(struct list_head *new, struct list_head *head)
{
	__list_add(new, head->prev, head);
}

void __list_del(struct list_head * prev, struct list_head * next)
{
	next->prev = prev;
	prev->next = next;
}

void list_del(struct list_head *entry)
{
	__list_del(entry->prev, entry->next);
}

int list_empty(const struct list_head *head)
{
	return head->next == head;
}

void INIT_LIST_HEAD(struct list_head *list)
{
	list->next = list;
	list->prev = list;
}
//-------------------------------------------------------------------------------

#define SIZE  5

#define  UP     1
#define  DOWN   2
#define  LEFT   3
#define  RIGHT  4

typedef struct
{
	int   f;
	int   fx;
	int   move_count;
	int   pre;
	int   map[SIZE][SIZE];
	struct list_head list;
} DATA;

struct list_head queue;

void init()
{
	INIT_LIST_HEAD(&queue);
}

void display( int board[SIZE][SIZE], int pattern[3][3] )
{
	int i,j;

	printf("board=\n");
	for( i=0; i<SIZE; i++)
	{
		for(j=0; j<SIZE; j++ )
		{
			printf("%2d", board[i][j]);
		}
		printf("\n");
	}

	printf("\npattern=\n");
	for( i=0; i<3; i++)
	{
		for(j=0; j<3; j++ )
		{
			printf("%2d", pattern[i][j]);
		}
		printf("\n");
	}
}

int queue_empty(void)
{
	return list_empty( &queue );
}


int calc_heuristic( int board[SIZE][SIZE], int pattern[3][3])
{
	int i, j;
	int cnt = 0;

	for( i = 0 ; i < 3 ; i ++)
	{
		for( j = 0 ; j < 3 ; j ++)
		{
			if( board[i+1][j+1] == pattern[i][j])
			{
				cnt++;
			}
		}
	}

	cnt = 9 - cnt;

	return cnt;
}

DATA* dequeue(void)
{
	struct list_head *temp;
	DATA *data;

	data = list_first_entry(&queue, DATA, list);
	list_del( &data->list );
	return data;
}

void swap( int board[SIZE][SIZE], int x, int y, int nx, int ny)
{
	int temp;

	temp            = board[y][x];
	board[y][x]     = board[ny][nx];
	board[ny][nx]   = temp;
}

void enqueue(int board[SIZE][SIZE], int pattern[3][3], int pre, int move)
{
	int i,j;
	DATA *data, *p;
	struct list_head *temp;

	data = calloc(1, sizeof(DATA));
	for(i=0; i<SIZE; i++)
		for(j=0; j<SIZE; j++)
			data->map[i][j] = board[i][j];

	data->move_count = move; 
	data->pre = pre; 
	data->fx = calc_heuristic( board, pattern);
	data->f = data->move_count + data->fx;

	if( list_empty(&queue) )
		list_add_tail( &data->list, &queue );
	else
	{
		list_for_each(temp, &queue)
		{
			p = list_entry(temp, DATA, list);
			if( data->f < p->f )
				break;
		}
		list_add_tail( &data->list, temp );
	}
	
	/*
	list_for_each(temp, &queue)
	{
		p = list_entry(temp, DATA, list);
		printf("%d ", p->f );
	}
	printf("\n");
	getchar();
	*/
}

int astar( int board[SIZE][SIZE], int pattern[3][3], int callCntLimit  )
{
	int sx  = 0, sy = 0;
	int i, j, result;
	DATA *data;
	int count=0;

	result  = 0;

	enqueue( board, pattern, 0, 0 );

	while( !queue_empty() )
	{

		data = dequeue();

		//display( data->map, pattern );

		count++;
		if(count > callCntLimit)
		{
			display( data->map, pattern );
			//getchar();
			break;
		}

		if( data->fx == 0 )
		{
			printf("count=%d\n", count );
			display( data->map, pattern );
			result  = data->move_count;
			break;
		}

		for( i = 0 ; i < SIZE ; i ++)
		{
			for( j = 0 ; j < SIZE ; j ++)
			{
				if( data->map[i][j] == 0)
				{
					sx  = j;
					sy  = i;
					break;
				}
			}
		}

		data->move_count++;

		if( sy - 1 >= 0 && data->pre != DOWN) 
		{
			swap( data->map, sx, sy, sx, sy-1);
			enqueue( data->map, pattern, UP, data->move_count);
			swap( data->map, sx, sy, sx, sy-1);
		}

		if( sy + 1 < SIZE && data->pre != UP) 
		{
			swap( data->map, sx, sy, sx, sy+1);
			enqueue( data->map, pattern, DOWN, data->move_count);
			swap( data->map, sx, sy, sx, sy+1);
		}

		if( sx + 1 < SIZE && data->pre != LEFT) 
		{
			swap( data->map, sx+1, sy, sx, sy);
			enqueue( data->map, pattern, RIGHT, data->move_count);
			swap( data->map, sx+1, sy, sx, sy);
		}

		if( sx - 1 >= 0 && data->pre != RIGHT) 
		{
			swap( data->map, sx-1, sy, sx, sy);
			enqueue( data->map, pattern, LEFT, data->move_count);
			swap( data->map, sx-1, sy, sx, sy);
		}

		free( data );
	}

	return result;
}

void solve( int board[SIZE][SIZE], int pattern[3][3], int callCntLimit )
{
	int result;
	result = astar(board, pattern, callCntLimit);
	printf( "%d\n", result );
}


int main()
{
	int ret;

	int board[SIZE][SIZE] = 
	{
		{1,1,1,1,6},
		{2,2,2,2,6},
		{3,3,3,3,6},
		{4,4,4,4,6},
		{5,5,5,5,0}
	};

	int pattern[3][3] = 
	{
		{1,0,2},
		{3,2,3},
		{3,4,4}
	};

	init();

	display( board, pattern );

	solve( board, pattern, 200000);
	
	//display( board, pattern );

	return 0;
}





