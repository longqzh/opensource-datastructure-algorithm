#include <stdio.h>
#include <malloc.h>

#undef  offsetof
#define offsetof(TYPE, MEMBER)	((size_t)&((TYPE *)0)->MEMBER)

#define container_of(ptr, type, member) ({			\
		const typeof( ((type *)0)->member ) *__mptr = (ptr);	\
		(type *)( (char *)__mptr - offsetof(type,member) );})

#define list_entry(ptr, type, member) \
	container_of(ptr, type, member)

#define list_first_entry(ptr, type, member) \
	list_entry((ptr)->next, type, member)

#define list_for_each(pos, head) \
	for (pos = (head)->next; pos != (head); pos = pos->next)

#define list_for_each_entry(pos, head, member)				\
	for (pos = list_first_entry(head, typeof(*pos), member);	\
			&pos->member != (head);					\
			pos = list_next_entry(pos, member))

struct list_head {
	struct list_head *next, *prev;
};

void __list_add(struct list_head *new,
		struct list_head *prev,
		struct list_head *next)
{
	next->prev = new;
	new->next = next;
	new->prev = prev;
	prev->next = new;
}

void list_add(struct list_head *new, struct list_head *head)
{
	__list_add(new, head, head->next);
}

void list_add_tail(struct list_head *new, struct list_head *head)
{
	__list_add(new, head->prev, head);
}

void __list_del(struct list_head * prev, struct list_head * next)
{
	next->prev = prev;
	prev->next = next;
}

void list_del(struct list_head *entry)
{
	__list_del(entry->prev, entry->next);
}

int list_empty(const struct list_head *head)
{
	return head->next == head;
}

void INIT_LIST_HEAD(struct list_head *list)
{
	list->next = list;
	list->prev = list;
}
//-------------------------------------------------------------------------------

void generic_swap( void *a, void *b, int size )
{
	char *x = (char*)a;
	char *y = (char*)b;
	char t;

	int i;

	for(i=0; i<size; i++ )
	{
		t = x[i];
		x[i] = y[i];
		y[i] = t;
	}
}


void sort(void *base, size_t num, size_t size,
		int (*cmp_func)(void *, void *))
{
	int i = (num/2 - 1) * size, n = num * size, c, r;
	void (*swap_func)(void *, void *, int size);

	swap_func = generic_swap;

	/* heapify */
	for ( ; i >= 0; i -= size) {
		for (r = i; r * 2 + size < n; r  = c) {
			c = r * 2 + size;
			if (c < n - size &&
					cmp_func(base + c, base + c + size) < 0)
				c += size;
			if (cmp_func(base + r, base + c) >= 0)
				break;
			swap_func(base + r, base + c, size);
		}
	}

	/* sort */
	for (i = n - size; i > 0; i -= size) {
		swap_func(base, base + i, size);
		for (r = 0; r * 2 + size < i; r = c) {
			c = r * 2 + size;
			if (c < i - size &&
					cmp_func(base + c, base + c + size) < 0)
				c += size;
			if (cmp_func(base + r, base + c) >= 0)
				break;
			swap_func(base + r, base + c, size);
		}
	}
}

//--------------------------------------------------------------------------------------

typedef struct
{
	int pid;
	int area;
	int price;
	struct list_head list;
} PRODUCT;

typedef struct
{
	int uid;
	struct list_head rlist_head;
} USER;

typedef struct
{
	PRODUCT *p;
} SORT_TABLE;

typedef struct
{
	int area;
	int count;
} AREA_TABLE;

struct list_head plist_head;

PRODUCT *product;
USER *user_table;
int *friend_table;
AREA_TABLE *area_table;

int product_count;
int user_count;
int area_count;

#define   FRIEND_MAP(row,col)   (friend_table[(row)*user_count+(col)])

void init(int N, int M)
{
	int i;

	user_count = N;
	area_count = M;
	product_count = 0;

	area_table = calloc(M, sizeof(AREA_TABLE));
	friend_table = calloc(N*N, sizeof(int));
	user_table = calloc(N, sizeof(USER));

	INIT_LIST_HEAD(&plist_head);

	for(i=0; i<user_count; i++ )
	{
		user_table[i].uid = i+1;
		INIT_LIST_HEAD(&user_table[i].rlist_head);
	}

}


void befriend( int uid1, int uid2 )
{
	FRIEND_MAP( uid1-1, uid2-1 ) = 1;
	FRIEND_MAP( uid2-1, uid1-1 ) = 1;
}

void add( int pid, int area, int price )
{
	PRODUCT *p;
	p = calloc(1, sizeof(PRODUCT));
	p->pid = pid;
	p->area = area;
	p->price = price;
	list_add_tail( &p->list, &plist_head );
}

void display(void)
{
	int i, j;
	struct list_head *temp;
	PRODUCT *p;

	for(i=0; i<user_count; i++ )
	{
		printf("uid=%d\n", user_table[i].uid);
		printf("friend=");
		for(j=0; j<user_count; j++ )
		{
			if( FRIEND_MAP(user_table[i].uid-1, j) )
				printf(" %d", j+1);
		}
		printf("\n");
		printf("[reserve_head]");
		list_for_each(temp, &user_table[i].rlist_head)
		{
			p = list_entry(temp, PRODUCT, list);
			printf("->[pid=%d,area=%d,price=%d]", p->pid, p->area, p->price);
		}
		printf("\n\n");
	}

	printf("상품리스트\n");
	list_for_each(temp, &plist_head)
	{
		p = list_entry(temp, PRODUCT, list);
		printf("[pid=%2d,area=%2d,price=%2d]\n", p->pid, p->area, p->price);
	}
	printf("\n\n");
}

void reserve(int uid, int pid)
{
	int i;
	PRODUCT *p;
	struct list_head *temp;
	for(i=0; i<user_count; i++ )
	{
		if( user_table[i].uid == uid  )
			break;
	}
	list_for_each(temp, &plist_head)
	{
		p = list_entry(temp, PRODUCT, list);
		if( p->pid == pid )
			break;
	}
	list_del( &p->list );
	list_add_tail( &p->list, &user_table[i].rlist_head );  
}

int my_product_compare(void *a, void *b)
{
	int ret = 0;
	SORT_TABLE *x = (SORT_TABLE*)a;
	SORT_TABLE *y = (SORT_TABLE*)b;

	if ( x->p->price - y->p->price == 0  )
	{
		ret = x->p->price - y->p->price;
	}
	else 
		ret = x->p->pid - y->p->pid ;

	return ret;
}

int my_area_compare(void *a, void *b)
{
	int ret = 0;
	AREA_TABLE *x = (AREA_TABLE*)a;
	AREA_TABLE *y = (AREA_TABLE*)b;

	ret = y->count - x->count;

	return ret;
}

int recommend( int uid )
{
	int pid;
	int i,j;
	PRODUCT *p;
	struct list_head *temp;
	int count=0;
	SORT_TABLE sort_table[10000] = {0,};
	int sort_count=0;

	for(i=0; i<area_count; i++ )
	{
		area_table[i].area = i+1;
		area_table[i].count = 0;
	}

	for(i=0; i<user_count; i++ )
	{
		if( user_table[i].uid == uid  )
		{
			list_for_each(temp, &user_table[i].rlist_head)
			{
				p = list_entry(temp, PRODUCT, list);
				area_table[p->area-1].count++;
				count++;
			}
			break;
		}
	}


	for(j=0; j<user_count; j++ )
	{
		if( FRIEND_MAP(i, j) )
		{
			list_for_each(temp, &user_table[j].rlist_head)
			{
				p = list_entry(temp, PRODUCT, list);
				area_table[p->area-1].count++;
				count++;
			}
		}
	}

	/*
	printf("area_table : count=%d\n", count );
	for(i=0; i<area_count; i++ )
		printf("area=%d, count=%d\n", area_table[i].area, area_table[i].count);
	printf("\n");
	*/

	if( count == 0 )
	{
		list_for_each(temp, &plist_head)
		{
			p = list_entry(temp, PRODUCT, list);
			sort_table[sort_count++].p = p;
		}
		sort(sort_table, sort_count, sizeof(sort_table[0]), my_product_compare);
		pid = sort_table[0].p->pid;
	}
	else
	{
		sort(area_table, area_count, sizeof(area_table[0]), my_area_compare);

		/*
		for(i=0; i<area_count; i++ )
			printf("area=%d, count=%d\n", area_table[i].area, area_table[i].count);
		printf("\n");
		*/

		for(i=0; i<area_count; i++ )
		{
			if( area_table[i].count == 0 )
				break;

			list_for_each(temp, &plist_head)
			{
				p = list_entry(temp, PRODUCT, list);

				for( j=i; j<area_count-1; j++ )
				{
					if( area_table[j].area == p->area )
					{
						sort_table[sort_count++].p = p;
					}
					if( area_table[j].count != area_table[j+1].count )
						break;
				}
			}

			//printf("sort_count=%d\n", sort_count );

			if( sort_count == 0 )
				continue;

			sort(sort_table, sort_count, sizeof(sort_table[0]), my_product_compare);
			pid = sort_table[0].p->pid;
			break;
		}

		if( sort_count == 0 )
		{
			list_for_each(temp, &plist_head)
			{
				p = list_entry(temp, PRODUCT, list);
				sort_table[sort_count++].p = p;
			}
			sort(sort_table, sort_count, sizeof(sort_table[0]), my_product_compare);
			pid = sort_table[0].p->pid;
		}
	}
	return pid;
}

int main()
{
	int ret;
	init(5, 4);
	befriend(5, 1);
	befriend(2, 4);
	befriend(1, 4);
	befriend(2, 1);

	add(71,1,10);
	add(67,4,8);
	add(43,3,4);
	add(3,2,4);
	add(75,4,4);

	ret = recommend(4);
	printf("ret=%d\n", ret );
	reserve(4, 75);

	ret = recommend(1);
	printf("ret=%d\n", ret );

	add(81,2,10);
	reserve(2, 67);
	add(69,1,5);
	add(55,3,6);

	ret = recommend(2);
	printf("ret=%d\n", ret );
	reserve(5, 69);

	ret = recommend(5);
	printf("ret=%d\n", ret );
	befriend(3, 5);
	befriend(3, 4);
	add(28,4,10);

	ret = recommend(3);
	printf("ret=%d\n", ret );
	display();

	return 0;
}











