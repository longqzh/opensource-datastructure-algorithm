#include <stdio.h>
#include <malloc.h>

//-------------------------------------------------------------------------------

void generic_swap( void *a, void *b, int size )
{
	char *x = (char*)a;
	char *y = (char*)b;
	char t;

	int i;

	for(i=0; i<size; i++ )
	{
		t = x[i];
		x[i] = y[i];
		y[i] = t;
	}
}

void sort(void *base, size_t num, size_t size,
		int (*cmp_func)(void *, void *))
{
	int i = (num/2 - 1) * size, n = num * size, c, r;
	void (*swap_func)(void *, void *, int size);

	swap_func = generic_swap;

	/* heapify */
	for ( ; i >= 0; i -= size) {
		for (r = i; r * 2 + size < n; r  = c) {
			c = r * 2 + size;
			if (c < n - size &&
					cmp_func(base + c, base + c + size) < 0)
				c += size;
			if (cmp_func(base + r, base + c) >= 0)
				break;
			swap_func(base + r, base + c, size);
		}
	}

	/* sort */
	for (i = n - size; i > 0; i -= size) {
		swap_func(base, base + i, size);
		for (r = 0; r * 2 + size < i; r = c) {
			c = r * 2 + size;
			if (c < i - size &&
					cmp_func(base + c, base + c + size) < 0)
				c += size;
			if (cmp_func(base + r, base + c) >= 0)
				break;
			swap_func(base + r, base + c, size);
		}
	}
}

//--------------------------------------------------------------------------------------

typedef struct
{
	int uid;
} USER;

typedef struct
{
	int friend_count;
	USER *p;
} SORT_TABLE;

USER *user_table;
int *friend_table;

int user_count;

#define   FRIEND_MAP(row,col)   (friend_table[(row)*user_count+(col)])

void init(int N)
{
	int i;
	user_count = N;

	friend_table = calloc(N*N, sizeof(int));
	user_table = calloc(N, sizeof(USER));

	for(i=0; i<user_count; i++ )
	{
		user_table[i].uid = i+1;
	}

}

void add( int id, int F, int ids[])
{
	int i;

	for(i=0; i<F; i++)
	{
		FRIEND_MAP( id-1, ids[i]-1 ) = 1;
		FRIEND_MAP( ids[i]-1, id-1 ) = 1;
	}
}

void del( int id1, int id2 )
{
	FRIEND_MAP( id1, id2 ) = 0;
	FRIEND_MAP( id2, id1 ) = 0;
}

int my_compare(void *a, void *b)
{
	int ret = 0;
	SORT_TABLE *x = (SORT_TABLE*)a;
	SORT_TABLE *y = (SORT_TABLE*)b;

	ret = y->friend_count - x->friend_count;

	if( ret == 0 )
	{
		ret = x->p->uid - y->p->uid;
	}

	return ret;
}

int recommend( int id, int list[] )
{
	int i, j, k;
	int f_count=0; 
	int f_temp[10000];
	SORT_TABLE sort_table[10000];
	int sort_count=0;

	for(i=0; i<user_count; i++ )
	{
		if( FRIEND_MAP(id-1, i) == 1 )
			f_temp[f_count++] = i;
	}

	if( f_count == 0 )
		return 0;

//	printf("f_temp = ");
//	for(i=0; i<f_count; i++ )
//		printf("%4d", f_temp[i]+1 );
//	printf("\n");

	for(i=0; i<user_count; i++ )
	{
		if( id-1 == i )
			continue;

		for(j=0; j<f_count; j++ )
			if( f_temp[j] == i )
				break;

		if( j < f_count )
			continue;

		for(j=0; j<user_count; j++ )
		{
			if( FRIEND_MAP(i, j) == 0 )
				continue;

			for(k=0; k<f_count; k++ )
			{
				if( f_temp[k] == j )
				{
					sort_table[sort_count].friend_count++;
				}
			}
		}
		if( sort_table[sort_count].friend_count > 0 )
			sort_table[sort_count++].p = &user_table[i];
	}

//	for(i=0; i<sort_count; i++ )
//		printf("%4d->%d", sort_table[i].friend_count, sort_table[i].p->uid );
//	printf("\n");

	sort(sort_table, sort_count, sizeof(sort_table[0]), my_compare);
	for(i=0; i<sort_count; i++ )
	{
		list[i] = sort_table[i].p->uid;
	}

	return sort_count;
}

void display( int n, int list[] )
{
	int i;

	for(i=0; i<n; i++ )
		printf("%4d", list[i] );
	printf("\n");
}

void display_map()
{
	int i,j;

	printf("%4s" , " " );
	for(i=0; i<user_count; i++ )
		printf("%4d" , i+1 );
	printf("\n");

	for(i=0; i<user_count; i++ )
	{
		printf("%4d" , i+1 );
		for(j=0; j<user_count; j++ )
		{
			printf("%4d", FRIEND_MAP(i, j) ); 
		}
		printf("\n");
	}
}

int main()
{
	int ret;
	int list[10000];
	int temp[][100] =
	{
		{3},
		{5, 6},
		{2},
		{1, 6},
		{3},
		{8, 2},
		{2, 6},
		{2},
		{7},
		{6},
		{2, 7},
		{6},
		{5, 7}
	};

	init(8);

	add(8, 1, temp[0]);
	add(1, 2, temp[1]);
	add(1, 1, temp[2]);
	add(3, 2, temp[3]);
	add(2, 1, temp[4]);
	add(4, 2, temp[5]);
	ret = recommend(2, list);
	display(ret, list);

	// display_map();

	ret = recommend(7, list);
	display(ret, list);
	del(1, 6);
	add(8, 2, temp[6]);
	add(6, 1, temp[7]);
	add(2, 1, temp[8]);
	del(6, 2);
	del(6, 3);
	add(3, 1, temp[9]);
	add(6, 2, temp[10]);
	add(1, 1, temp[11]);
	add(3, 2, temp[12]);
	ret = recommend(8, list);
	display(ret, list);

	return 0;
}


