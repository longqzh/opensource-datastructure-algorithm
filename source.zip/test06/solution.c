#include <stdio.h>
#include <malloc.h>

//-------------------------------------------------------------------------------

size_t my_strlen(const char *s)
{
	const char *sc;

	for (sc = s; *sc != '\0'; ++sc)
		/* nothing */;
	return sc - s;
}

int my_strcmp(const char *cs, const char *ct)
{
	unsigned char c1, c2;

	while (1) {
		c1 = *cs++;
		c2 = *ct++;
		if (c1 != c2)
			return c1 < c2 ? -1 : 1;
		if (!c1)
			break;
	}
	return 0;
}

int my_strncmp(char * cs, char * ct, int count)
{
	char res = 0;

	while (count) {
		if ((res = *cs - *ct++) != 0 || !*cs++)
			break;
		count--;
	}

	return res;
}

char *my_strncpy(char *dest, const char *src, size_t count)
{
	char *tmp = dest;

	while (count) {
		if ((*tmp = *src) != 0)
			src++;
		tmp++;
		count--;
	}
	return dest;
}

char * my_strcpy(char * dest,char *src)
{
	char *tmp = dest;

	while ((*dest++ = *src++) != '\0')
		/* nothing */;
	return tmp;
}

char * my_strchr(const char * s, int c)
{
	for(; *s != (char) c; ++s)
		if (*s == '\0')
			return NULL;
	return (char *) s;
}

int my_memcmp(const void *cs, const void *ct, size_t count)
{
	const unsigned char *su1, *su2;
	int res = 0;

	for (su1 = cs, su2 = ct; 0 < count; ++su1, ++su2, count--)
		if ((res = *su1 - *su2) != 0)
			break;
	return res;
}

char *my_strstr(char *s1, char *s2)
{
	size_t l1, l2;

	l2 = my_strlen(s2);
	if (!l2)
		return (char *)s1;
	l1 = my_strlen(s1);
	while (l1 >= l2) {
		l1--;
		if (!my_memcmp(s1, s2, l2))
			return (char *)s1;
		s1++;
	}
	return NULL;
}
//-----------------------------------------------------------------------
typedef struct
{
	int msgID;
	int userID;
	char mtime[20];
	char hashTag[100];
} TABLE;

typedef struct
{
	int userID1;
	int userID2;
} FOLLOW_TABLE;

typedef struct
{
	int index;
} SORT_TABLE;

TABLE *table;
int table_count;

FOLLOW_TABLE *follow_table;
int follow_count;

void init()
{
	table = calloc(100000, sizeof(TABLE));
	follow_table = calloc(100000, sizeof(FOLLOW_TABLE));
	table_count=0;
	follow_count=0;
}

void createMessage( int msgID, int userID, char msgData[] )
{
	char *start, *end;
	int n;
	table[table_count].msgID = msgID;
	table[table_count].userID = userID;

	start = msgData;
	end = my_strchr( start, ' ');
	n = end - start;
	my_strncpy(table[table_count].mtime , start, n);
	table[table_count].mtime[n] = 0;

	start = my_strchr( start, '#');
	my_strcpy(table[table_count].hashTag , start);
	table_count++;
}

void followUser( int userID1, int userID2 )
{
	follow_table[follow_count].userID1 = userID1;
	follow_table[follow_count].userID2 = userID2;
	follow_count++;
}



void display(int list[])
{
	int i;

	for(i=0; list[i]>=0 && i<5; i++ )
	{
		printf("%d ", table[list[i]].msgID);
	}
	printf("\n");
}

int my_compare(void *a, void *b)
{
	int ret = 0;
	SORT_TABLE *x = (SORT_TABLE*)a;
	SORT_TABLE *y = (SORT_TABLE*)b;

	if ( my_strcmp( table[y->index].mtime, table[x->index].mtime) == 0  )
	{
		ret = table[x->index].userID - table[y->index].userID;
	}
	else 
		ret = my_strcmp( table[y->index].mtime, table[x->index].mtime ) ;

	return ret;
}

void generic_swap( void *a, void *b, int size )
{
	char *x = (char*)a;
	char *y = (char*)b;
	char t;

	int i;

	for(i=0; i<size; i++ )
	{
		t = x[i];
		x[i] = y[i];
		y[i] = t;
	}
}


void sort(void *base, size_t num, size_t size,
	  int (*cmp_func)(void *, void *))
{
	int i = (num/2 - 1) * size, n = num * size, c, r;
	 void (*swap_func)(void *, void *, int size);

	swap_func = generic_swap;
	
	/* heapify */
	for ( ; i >= 0; i -= size) {
		for (r = i; r * 2 + size < n; r  = c) {
			c = r * 2 + size;
			if (c < n - size &&
					cmp_func(base + c, base + c + size) < 0)
				c += size;
			if (cmp_func(base + r, base + c) >= 0)
				break;
			swap_func(base + r, base + c, size);
		}
	}

	/* sort */
	for (i = n - size; i > 0; i -= size) {
		swap_func(base, base + i, size);
		for (r = 0; r * 2 + size < i; r = c) {
			c = r * 2 + size;
			if (c < i - size &&
					cmp_func(base + c, base + c + size) < 0)
				c += size;
			if (cmp_func(base + r, base + c) >= 0)
				break;
			swap_func(base + r, base + c, size);
		}
	}
}

int searchByHashtag( char tagName[], int retIDs[] )
{
	SORT_TABLE temp[100000];
	int temp_count=0;
	int i;
	char *p;

	for(i=0; i<table_count; i++ )
	{
		p = my_strstr( table[i].hashTag, tagName );
		if( p )
		{
			temp[temp_count].index = i;
			temp_count++;
		}
	}

	sort(temp, temp_count, sizeof(temp[0]), my_compare);

	for(i=0; i<5 && i<temp_count; i++ )
		retIDs[i] = temp[i].index;

	retIDs[i] = -1;
}

int getMessages( int userID, int retIDs[] )
{
	SORT_TABLE temp[100000];
	int temp_count=0;
	int i, j;
	char *p;

	for(i=0; i<table_count; i++ )
	{
		if( userID == table[i].userID )
		{
			temp[temp_count].index = i;
			temp_count++;
		}
		for(j=0; j<follow_count; j++ )
		{
			if( userID == follow_table[j].userID1 )
			{
				if( table[i].userID == follow_table[j].userID2 )
				{
					temp[temp_count].index = i;
					temp_count++;
				}
			}
		}
	}

	sort(temp, temp_count, sizeof(temp[0]), my_compare);

	for(i=0; i<5 && i<temp_count; i++ )
		retIDs[i] = temp[i].index;

	retIDs[i] = -1;
}

int main()
{
	int retIDs[5];
	init();
	createMessage(1, 111, "01:12:34 #watch #work");
	createMessage(5, 222, "01:12:34 #game");
	createMessage(3, 333, "01:12:34 #dinner #watch");
	createMessage(9, 333, "01:12:37 #dog #eat");
	followUser(222, 333);
	searchByHashtag("#event", retIDs);
	getMessages(555, retIDs);
	createMessage(2, 333, "01:12:38 #dog #eat");
    getMessages(222, retIDs);
	display(retIDs);
	followUser(111, 333);
	createMessage(7, 333, "01:13:00 #watch #game");
	searchByHashtag("#game", retIDs);
	display(retIDs);
	createMessage(8, 333, "01:14:37 #watch #eat");
	followUser(333, 111);
	getMessages(333, retIDs);
	display(retIDs);
	createMessage(6, 333, "01:15:07 #table #watch");
	getMessages(111, retIDs);
	display(retIDs);
	createMessage(4, 111, "01:15:10 #dinner #watch");
	searchByHashtag("#watch", retIDs);
	display(retIDs);
	searchByHashtag("#eat", retIDs);
	display(retIDs);

	return 0;
}
