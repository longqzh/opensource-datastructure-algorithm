#include <stdio.h>
#include <malloc.h>

typedef struct
{
	int pID;
	int uID;
	int like;
	int timestamp;
} TABLE;

typedef struct
{
	int uID1;
	int uID2;
	int timestamp;
} FOLLOW_TABLE;

typedef struct
{
	int index;
	int time_expire;
} SORT_TABLE;

TABLE *table;
int table_count;

FOLLOW_TABLE *follow_table;
int follow_count;

void init( int n )
{
	table = calloc(100000, sizeof(TABLE));
	follow_table = calloc(100000, sizeof(FOLLOW_TABLE));
	table_count=0;
	follow_count=0;
}

void follow( int uID1, int uID2, int timestamp )
{
	follow_table[follow_count].uID1 = uID1;
	follow_table[follow_count].uID2 = uID2;
	follow_table[follow_count].timestamp = timestamp;
	follow_count++;
}

void makePost( int uID, int pID, int timestamp )
{
	table[table_count].pID = pID;
	table[table_count].uID = uID;
	table[table_count].timestamp = timestamp;
	table_count++;
}

void like( int pID, int timestamp )
{
	int i;
	for(i=0; i<table_count; i++ )
		if( pID == table[i].pID )
			break;

	table[i].like++;
}

void display(int pIDList[])
{
	int i;

	for(i=0; pIDList[i]>=0 && i<10; i++ )
		printf("%4d", table[pIDList[i]].pID);
	printf("\n");
	/*
	printf("table \n");
	for(i=0; i<table_count; i++ )
		printf("%4d %4d %4d %6d\n", table[i].pID,  table[i].uID, table[i].like, table[i].timestamp);

	printf("\n");	
	printf("follow_table \n");
	for(i=0; i<follow_count; i++ )
		printf("%4d %4d %6d\n", follow_table[i].uID1, follow_table[i].uID2, follow_table[i].timestamp);
		*/
}

int my_timeexpire_compare(void *a, void *b)
{
	int ret = 0;
	SORT_TABLE *x = (SORT_TABLE*)a;
	SORT_TABLE *y = (SORT_TABLE*)b;

	if ( x->time_expire == y->time_expire )
	{
		if( x->time_expire == 0 )
		{
			ret = table[y->index].like - table[x->index].like;
			if( ret == 0 )
			{
				ret = table[y->index].timestamp - table[x->index].timestamp;
			}
		}
		else
		{
			ret = table[y->index].timestamp - table[x->index].timestamp;
		}
	}
	else 
		ret = x->time_expire - y->time_expire;

	return ret;
}

void generic_swap( void *a, void *b, int size )
{
	char *x = (char*)a;
	char *y = (char*)b;
	char t;

	int i;

	for(i=0; i<size; i++ )
	{
		t = x[i];
		x[i] = y[i];
		y[i] = t;
	}
}


void sort(void *base, size_t num, size_t size,
	  int (*cmp_func)(void *, void *))
{
	int i = (num/2 - 1) * size, n = num * size, c, r;
	 void (*swap_func)(void *, void *, int size);

	swap_func = generic_swap;
	
	/* heapify */
	for ( ; i >= 0; i -= size) {
		for (r = i; r * 2 + size < n; r  = c) {
			c = r * 2 + size;
			if (c < n - size &&
					cmp_func(base + c, base + c + size) < 0)
				c += size;
			if (cmp_func(base + r, base + c) >= 0)
				break;
			swap_func(base + r, base + c, size);
		}
	}

	/* sort */
	for (i = n - size; i > 0; i -= size) {
		swap_func(base, base + i, size);
		for (r = 0; r * 2 + size < i; r = c) {
			c = r * 2 + size;
			if (c < i - size &&
					cmp_func(base + c, base + c + size) < 0)
				c += size;
			if (cmp_func(base + r, base + c) >= 0)
				break;
			swap_func(base + r, base + c, size);
		}
	}
}
/*
void sort( void *a, int n, int size, int (*compare)(void *a, void *b))
{
	char *x = (char*)a;
	int i, j;

	for(i=0; i<n-1; i++ )
		for(j=0; j<n-1-i; j++ )
			if( compare( x+j*size, x+(j+1)*size) > 0 )
				generic_swap( x+j*size, x+(j+1)*size, size ); 
}
*/

void getFeed( int uID, int timestamp, int pIDList[] )
{
	int i;
	int j;
	int count=0; 
	SORT_TABLE temp[100000];
	int temp_count=0;
	for(i=0; i<table_count; i++ )
	{
		for(j=0; j<follow_count; j++ )
		{
			if( follow_table[j].uID1 == uID )
			{
				if( table[i].uID == follow_table[j].uID2 )
				{
					temp[temp_count].time_expire = (timestamp - table[i].timestamp > 1000);
					temp[temp_count++].index = i;
				}
			}
		}
		if( table[i].uID == uID )
		{
			temp[temp_count].time_expire = (timestamp - table[i].timestamp > 1000);
			temp[temp_count++].index = i;
		}
	}

	printf("temp_count=%d\n", temp_count );

	sort(temp, temp_count, sizeof(temp[0]), my_timeexpire_compare);

	for(i=0; i<10 && i<temp_count; i++ )
		pIDList[i] = temp[i].index;

	if( i < 10 )
		pIDList[i] = -1;

	display(pIDList);
}

int main()
{
	int pIDList[10];
	init(100000);
	follow(1, 2, 1);
	follow(2, 1, 1);
	getFeed(2, 534, pIDList);
	getFeed(2, 766, pIDList);
	getFeed(1, 1088, pIDList);
	makePost(1, 1, 1752);
	like(1, 1861);
	makePost(1, 2, 2027);
	makePost(2, 3, 2117);
	makePost(1, 4, 2163);
	getFeed(1, 2476, pIDList);
	like(2, 2494);
	like(1, 2542);
	makePost(1, 5, 2666);
	getFeed(2, 2853, pIDList);
	like(3, 2944);
	getFeed(2, 3033, pIDList);
	return 0;
}
