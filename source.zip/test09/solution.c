#include <stdio.h>
#include <malloc.h>

#undef  offsetof
#define offsetof(TYPE, MEMBER)	((size_t)&((TYPE *)0)->MEMBER)

#define container_of(ptr, type, member) ({			\
		const typeof( ((type *)0)->member ) *__mptr = (ptr);	\
		(type *)( (char *)__mptr - offsetof(type,member) );})

#define list_entry(ptr, type, member) \
	container_of(ptr, type, member)

#define list_first_entry(ptr, type, member) \
	list_entry((ptr)->next, type, member)

#define list_for_each(pos, head) \
	for (pos = (head)->next; pos != (head); pos = pos->next)

#define list_for_each_entry(pos, head, member)				\
	for (pos = list_first_entry(head, typeof(*pos), member);	\
			&pos->member != (head);					\
			pos = list_next_entry(pos, member))

#define list_for_each_safe(pos, n, head) \
	for (pos = (head)->next, n = pos->next; pos != (head); \
		pos = n, n = pos->next)

struct list_head {
	struct list_head *next, *prev;
};

void __list_add(struct list_head *new,
		struct list_head *prev,
		struct list_head *next)
{
	next->prev = new;
	new->next = next;
	new->prev = prev;
	prev->next = new;
}

void list_add(struct list_head *new, struct list_head *head)
{
	__list_add(new, head, head->next);
}

void list_add_tail(struct list_head *new, struct list_head *head)
{
	__list_add(new, head->prev, head);
}

void __list_del(struct list_head * prev, struct list_head * next)
{
	next->prev = prev;
	prev->next = next;
}

void list_del(struct list_head *entry)
{
	__list_del(entry->prev, entry->next);
}

int list_empty(const struct list_head *head)
{
	return head->next == head;
}

void INIT_LIST_HEAD(struct list_head *list)
{
	list->next = list;
	list->prev = list;
}
//-------------------------------------------------------------------------------
int my_strcmp(const char *cs, const char *ct)
{
	unsigned char c1, c2;

	while (1) {
		c1 = *cs++;
		c2 = *ct++;
		if (c1 != c2)
			return c1 < c2 ? -1 : 1;
		if (!c1)
			break;
	}
	return 0;
}

int my_strncmp(char * cs, char * ct, int count)
{
	char res = 0;

	while (count) {
		if ((res = *cs - *ct++) != 0 || !*cs++)
			break;
		count--;
	}

	return res;
}

char *my_strncpy(char *dest, const char *src, size_t count)
{
	char *tmp = dest;

	while (count) {
		if ((*tmp = *src) != 0)
			src++;
		tmp++;
		count--;
	}
	return dest;
}

char * my_strcpy(char * dest,char *src)
{
	char *tmp = dest;

	while ((*dest++ = *src++) != '\0')
		/* nothing */;
	return tmp;
}

char * my_strchr(const char * s, int c)
{
	for(; *s != (char) c; ++s)
		if (*s == '\0')
			return NULL;
	return (char *) s;
}

char *my_strpbrk(const char *cs, const char *ct)
{
	const char *sc1, *sc2;

	for (sc1 = cs; *sc1 != '\0'; ++sc1) {
		for (sc2 = ct; *sc2 != '\0'; ++sc2) {
			if (*sc1 == *sc2)
				return (char *)sc1;
		}
	}
	return NULL;
}

char *my_strsep(char **s, const char *ct)
{
	char *sbegin = *s;
	char *end;

	if (sbegin == NULL)
		return NULL;

	end = my_strpbrk(sbegin, ct);
	if (end)
		*end++ = '\0';
	*s = end;
	return sbegin;
}
//-----------------------------------------------------------------------

typedef struct
{
	int uid;
	int count;
	struct list_head mail_list_head;
} USER;

typedef struct
{
	char subject[200];
	struct list_head list;
} MAIL;

USER *user_table;

int user_count;
int mail_count;

void init(int N, int K)
{
	int i;

	user_count = N;
	mail_count = K;

	user_table = calloc(N, sizeof(USER));

	for(i=0; i<user_count; i++ )
	{
		user_table[i].uid = i;
		user_table[i].count = 0;
		INIT_LIST_HEAD(&user_table[i].mail_list_head);
	}
}

void display(void)
{
	int i, j;
	struct list_head *temp;
	MAIL *p;

	for(i=0; i<user_count; i++ )
	{
		printf("uid=%d\n", user_table[i].uid);
		printf("[mail_list]");
		list_for_each(temp, &user_table[i].mail_list_head)
		{
			p = list_entry(temp, MAIL, list);
			printf("->[%s]", p->subject);
		}
		printf("\n\n");
	}
}

void sendMail( char subject[], int uID, int cnt, int rIDs[])
{
	int i, j;
	MAIL *p;

	for(i=0; i<cnt; i++ )
	{
		p = calloc(1, sizeof(MAIL));
		my_strcpy( p->subject, subject );
		user_table[rIDs[i]].count++;
		list_add_tail( &p->list, &user_table[rIDs[i]].mail_list_head );
	}
}

int getCount(int uID)
{
	return user_table[uID].count;
}

int deleteMail( int uID, char subject[] )
{
	struct list_head *temp, *n;
	MAIL *p;
	int remove_count=0;

	list_for_each_safe(temp, n, &user_table[uID].mail_list_head)
	{
		p = list_entry( temp, MAIL, list );
		if( my_strcmp( subject, p->subject) == 0 )
		{
			list_del( temp );
			free(p);
			remove_count++;
		}
	}
	return remove_count;
}

int searchMail(int uID, char text[] )
{
	struct list_head *temp;
	MAIL *p;
	char subject[200];
	char *save_ptr, *start;
	int search_count=0;

	list_for_each(temp, &user_table[uID].mail_list_head)
	{
		p = list_entry( temp, MAIL, list );
		my_strcpy(subject, p->subject);

		save_ptr = subject;
		start = my_strsep( &save_ptr, " ");

		while(start)
		{
			if( my_strcmp( start, text ) == 0 )
			{
				search_count++;
				break;
			}

			start = my_strsep( &save_ptr, " ");
		}
	}

	return search_count;
}

int main()
{
	int ret;
	int temp[10][100] = 
	{
		{0, 1, 2},
		{2, 3},
		{0, 2},
	    {0, 1},
		{0, 3}
	};
	init(5, 3);

	
	sendMail("test email abcd", 0, 3, temp[0]);
	sendMail("test email abcd", 0, 2, temp[1]);
	sendMail("test key test aaa", 1, 2, temp[2]);
	ret = getCount(2);
	printf("ret=%d\n", ret );

	ret = searchMail(2, "test");
	printf("ret=%d\n", ret );

	ret = deleteMail(2, "test email abcd");
	printf("ret=%d\n", ret );

	sendMail("key subject", 3, 2, temp[3]);

	ret = searchMail(0, "abcd");
	printf("ret=%d\n", ret );

	sendMail("subject mail", 2, 2, temp[4]);

	ret = searchMail(0, "sub");
	printf("ret=%d\n", ret );

	ret = deleteMail(2, "dummy age");
	printf("ret=%d\n", ret );

	ret = searchMail(0, "goto");
	printf("ret=%d\n", ret );

	//display();

	return 0;
}











