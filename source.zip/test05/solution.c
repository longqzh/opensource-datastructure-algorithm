#include <stdio.h>
#include <malloc.h>

#undef  offsetof
#define offsetof(TYPE, MEMBER)	((size_t)&((TYPE *)0)->MEMBER)

#define container_of(ptr, type, member) ({			\
	const typeof( ((type *)0)->member ) *__mptr = (ptr);	\
	(type *)( (char *)__mptr - offsetof(type,member) );})

#define list_entry(ptr, type, member) \
	container_of(ptr, type, member)

#define list_first_entry(ptr, type, member) \
	list_entry((ptr)->next, type, member)

#define list_for_each(pos, head) \
	for (pos = (head)->next; pos != (head); pos = pos->next)

#define list_for_each_entry(pos, head, member)				\
	for (pos = list_first_entry(head, typeof(*pos), member);	\
	     &pos->member != (head);					\
	     pos = list_next_entry(pos, member))

struct list_head {
	struct list_head *next, *prev;
};

void __list_add(struct list_head *new,
			      struct list_head *prev,
			      struct list_head *next)
{
	next->prev = new;
	new->next = next;
	new->prev = prev;
	prev->next = new;
}

void list_add(struct list_head *new, struct list_head *head)
{
	__list_add(new, head, head->next);
}

void list_add_tail(struct list_head *new, struct list_head *head)
{
	__list_add(new, head->prev, head);
}

void __list_del(struct list_head * prev, struct list_head * next)
{
	next->prev = prev;
	prev->next = next;
}

void list_del(struct list_head *entry)
{
	__list_del(entry->prev, entry->next);
}

int list_empty(const struct list_head *head)
{
	return head->next == head;
}

void INIT_LIST_HEAD(struct list_head *list)
{
	list->next = list;
	list->prev = list;
}

//-------------------------------------------------------------------------------

int my_strcmp(const char *cs, const char *ct)
{
	unsigned char c1, c2;

	while (1) {
		c1 = *cs++;
		c2 = *ct++;
		if (c1 != c2)
			return c1 < c2 ? -1 : 1;
		if (!c1)
			break;
	}
	return 0;
}

int my_strncmp(char * cs, char * ct, int count)
{
	char res = 0;

	while (count) {
		if ((res = *cs - *ct++) != 0 || !*cs++)
			break;
		count--;
	}

	return res;
}

char *my_strncpy(char *dest, const char *src, size_t count)
{
	char *tmp = dest;

	while (count) {
		if ((*tmp = *src) != 0)
			src++;
		tmp++;
		count--;
	}
	return dest;
}

char * my_strcpy(char * dest,char *src)
{
	char *tmp = dest;

	while ((*dest++ = *src++) != '\0')
		/* nothing */;
	return tmp;
}

char * my_strchr(const char * s, int c)
{
	for(; *s != (char) c; ++s)
		if (*s == '\0')
			return NULL;
	return (char *) s;
}

//-----------------------------------------------------------------------

typedef struct _dirent
{
	char path[256];
	struct _dirent *parent;
	struct list_head childrens;
	struct list_head sibling;
} DIRENT;

DIRENT *root;
int dir_count;

void init(int N)
{
	dir_count = N;
	root = calloc( 1, sizeof(DIRENT) );
	my_strcpy( root->path, "/" );
    INIT_LIST_HEAD(&root->childrens);
    INIT_LIST_HEAD(&root->sibling);
}

DIRENT* find_dir(char path[2000])
{
	DIRENT *p, *child;
	struct list_head *temp;
	char *start, *end;
	char name[16];
	int n;

	start = path;
	p = root;

	while( *start != 0 )
	{
		start = my_strchr(start, '/');
		if( start == 0 )
			break;

		start++;
		if( *start == 0 )
			break;

		end = my_strchr(start, '/');
		if( end == 0 )
			break;

		n = end - start;
		my_strncpy( name, start, n );
		name[n] = 0;
//		printf("[%s]\n", name );

		list_for_each( temp, &p->childrens )
		{
			child = list_entry( temp, DIRENT, sibling );
			if( my_strcmp( name, child->path ) == 0 )
			{
				p = child;
				break;
			}
		}
	}
	return p;
}

struct list_head* cp_recur( struct list_head* head )
{
	struct list_head *temp, *ret;
	DIRENT *p, *parent, *self;

	p = calloc( 1, sizeof(DIRENT) );
	self = list_entry( head, DIRENT, childrens);
	my_strcpy( p->path, self->path );
    INIT_LIST_HEAD(&p->childrens);

	list_for_each(temp, head)
	{
		parent = list_entry( temp, DIRENT, sibling);
		ret = cp_recur( &parent->childrens );
		list_add_tail( ret, &p->childrens);
	}

	return &p->sibling;
}

void cmd_mkdir(char path[2000], char name[7] )
{
	DIRENT *parent, *temp;
	parent = find_dir(path);
	printf("parent=[%s]\n", parent->path);

	if( parent != 0 )
	{
		temp = malloc( sizeof(DIRENT) );
		my_strcpy( temp->path, name );
    	INIT_LIST_HEAD(&temp->childrens);
		temp->parent = parent;
		list_add_tail( &temp->sibling, &parent->childrens );
	}
}

void _dir_rm( struct list_head *head)
{
	struct list_head *temp;
	DIRENT *p, *self;

	list_for_each(temp, head)
	{
		p = list_entry( temp, DIRENT, sibling);
		_dir_rm( &p->childrens );
	}

	self = list_entry( head, DIRENT, childrens);
	list_del(&self->sibling);
	free(self);
}

void cmd_rm(char path[2000])
{
	DIRENT *src;
	src = find_dir(path);
	_dir_rm( &src->childrens );
}

void cmd_cp(char srcPath[2000], char dstPath[2000])
{
	DIRENT *src, *dst, *p;
	struct list_head *temp;

	src = find_dir(srcPath);
	dst = find_dir(dstPath);
	//printf("src=%s\n", src->path);
	//printf("dst=%s\n", dst->path);
	temp = cp_recur( &src->childrens );
	p = list_entry(temp, DIRENT, sibling);
	p->parent = dst;
	list_add_tail( temp,  &dst->childrens );
}

void cmd_mv(char srcPath[2000], char dstPath[2000])
{
	DIRENT *src, *dst, *parent;
	struct list_head *temp;

	src = find_dir(srcPath);
	dst = find_dir(dstPath);
	list_del( &src->sibling);
	src->parent = dst;
	list_add_tail( &src->sibling,  &dst->childrens );
}

void _dir_count( struct list_head *head, int *count)
{
	struct list_head *temp;
	DIRENT *p;

	++*count;

	list_for_each(temp, head)
	{
		p = list_entry( temp, DIRENT, sibling);
		_dir_count( &p->childrens, count );
	}
}

int cmd_find(char path[2000])
{
	DIRENT *src;
	int count=-1;
	src = find_dir(path);
	_dir_count( &src->childrens, &count );
	return count;
}

void _display( struct list_head *head, int *indent)
{
	struct list_head *temp;
	DIRENT *p;

	++*indent;

	p = list_entry( head, DIRENT, childrens);
	printf("%*s\n", *indent*6, p->path);

	list_for_each(temp, head)
	{
		p = list_entry( temp, DIRENT, sibling);
		_display( &p->childrens, indent );
	}

	--*indent;
}

void display()
{
	int indent=-1;
	_display(&root->childrens, &indent);
}

int main()
{
	int ret;
	init(1000);
	cmd_mkdir("/", "aa");
	cmd_mkdir("/", "bb");
	cmd_mkdir("/aa/", "cc");
	cmd_mkdir("/bb/", "dd");
	cmd_cp("/bb/", "/aa/");
	cmd_mv("/aa/cc/", "/");
	ret = cmd_find("/");
	printf("ret=%d\n", ret );
	cmd_mv("/bb/", "/cc/");
	ret = cmd_find("/cc/");
	printf("ret=%d\n", ret );
	cmd_rm("/cc/");
	ret = cmd_find("/");
	printf("ret=%d\n", ret );
	display();
	return 0;
}
