#include <stdio.h>
#include <malloc.h>

#undef  offsetof
#define offsetof(TYPE, MEMBER)	((size_t)&((TYPE *)0)->MEMBER)

#define container_of(ptr, type, member) ({			\
		const typeof( ((type *)0)->member ) *__mptr = (ptr);	\
		(type *)( (char *)__mptr - offsetof(type,member) );})

#define list_entry(ptr, type, member) \
	container_of(ptr, type, member)

#define list_first_entry(ptr, type, member) \
	list_entry((ptr)->next, type, member)

#define list_for_each(pos, head) \
	for (pos = (head)->next; pos != (head); pos = pos->next)

#define list_for_each_entry(pos, head, member)				\
	for (pos = list_first_entry(head, typeof(*pos), member);	\
			&pos->member != (head);					\
			pos = list_next_entry(pos, member))

#define list_for_each_safe(pos, n, head) \
	for (pos = (head)->next, n = pos->next; pos != (head); \
		pos = n, n = pos->next)

struct list_head {
	struct list_head *next, *prev;
};

void __list_add(struct list_head *new,
		struct list_head *prev,
		struct list_head *next)
{
	next->prev = new;
	new->next = next;
	new->prev = prev;
	prev->next = new;
}

void list_add(struct list_head *new, struct list_head *head)
{
	__list_add(new, head, head->next);
}

void list_add_tail(struct list_head *new, struct list_head *head)
{
	__list_add(new, head->prev, head);
}

void __list_del(struct list_head * prev, struct list_head * next)
{
	next->prev = prev;
	prev->next = next;
}

void list_del(struct list_head *entry)
{
	__list_del(entry->prev, entry->next);
}

int list_empty(const struct list_head *head)
{
	return head->next == head;
}

void INIT_LIST_HEAD(struct list_head *list)
{
	list->next = list;
	list->prev = list;
}
//-------------------------------------------------------------------------------
int my_strcmp(const char *cs, const char *ct)
{
	unsigned char c1, c2;

	while (1) {
		c1 = *cs++;
		c2 = *ct++;
		if (c1 != c2)
			return c1 < c2 ? -1 : 1;
		if (!c1)
			break;
	}
	return 0;
}

int my_strncmp(char * cs, char * ct, int count)
{
	char res = 0;

	while (count) {
		if ((res = *cs - *ct++) != 0 || !*cs++)
			break;
		count--;
	}

	return res;
}

char *my_strncpy(char *dest, const char *src, size_t count)
{
	char *tmp = dest;

	while (count) {
		if ((*tmp = *src) != 0)
			src++;
		tmp++;
		count--;
	}
	return dest;
}

char * my_strcpy(char * dest,char *src)
{
	char *tmp = dest;

	while ((*dest++ = *src++) != '\0')
		/* nothing */;
	return tmp;
}

char * my_strchr(const char * s, int c)
{
	for(; *s != (char) c; ++s)
		if (*s == '\0')
			return NULL;
	return (char *) s;
}

char *my_strpbrk(const char *cs, const char *ct)
{
	const char *sc1, *sc2;

	for (sc1 = cs; *sc1 != '\0'; ++sc1) {
		for (sc2 = ct; *sc2 != '\0'; ++sc2) {
			if (*sc1 == *sc2)
				return (char *)sc1;
		}
	}
	return NULL;
}

char *my_strsep(char **s, const char *ct)
{
	char *sbegin = *s;
	char *end;

	if (sbegin == NULL)
		return NULL;

	end = my_strpbrk(sbegin, ct);
	if (end)
		*end++ = '\0';
	*s = end;
	return sbegin;
}
//-----------------------------------------------------------------------

typedef struct
{
	int id;
	char name[11];
	char tag[11];
	int r;
	int c;
	int height;
	int width;
	struct list_head list;
} RECT;

struct list_head rect_list;

int id_count;
int max_r;
int max_c;

void init(int R, int C)
{
	max_r = R;
	max_c = C;
	INIT_LIST_HEAD(&rect_list);
}

void display(void)
{
	int i, j;
	struct list_head *temp;
	RECT *r;

	int table[100][100] = {0,};

	list_for_each(temp, &rect_list)
	{
		r = list_entry(temp, RECT, list);
		printf("name=%s, tag=%s, r=%d, c=%d, height=%d, width=%d\n", 
				r->name, r->tag, r->r+1, r->c+1, r->height, r->width ); 
	}
	printf("\n");

	list_for_each(temp, &rect_list)
	{
		r = list_entry(temp, RECT, list);
		for(i=r->r; i<r->r+r->height; i++ )
		{
			for(j=r->c; j<r->c+r->width; j++ )
			{
				table[i][j] = r->id;
			}
		}
	}

	for(i=0; i<max_r; i++ )
	{
		for(j=0; j<max_c; j++ )
		{
			printf("%2d ", table[i][j] );
		}
		printf("\n");
	}
}

int getIntersection( RECT *r1, RECT *r2)
{
	if(r1->c >= r2->c+r2->width) return 0;
	if(r1->c+r1->width <= r2->c ) return 0;
	if(r1->r >= r2->r+r2->height) return 0;
	if(r1->r+r1->height <= r2->r ) return 0;

	return 1;
}


int addItem(char name[], char tag[], int height, int width, int mode, int r, int c)
{
	int ret=0;
	int i,j;
	int flag=0;

	struct list_head *temp;
	RECT *p, *rect;
	RECT temp_r;

	my_strcpy( temp_r.name, name );
	my_strcpy( temp_r.tag, tag );
	temp_r.r = r-1;
	temp_r.c = c-1;
	temp_r.height = height;
	temp_r.width = width;

	if( mode == 0 )
	{
		list_for_each(temp, &rect_list)
		{
			p = list_entry(temp, RECT, list);
			ret = getIntersection( p, &temp_r );
			if( ret == 0 )
			{
				break;
			}
		}
		if( list_empty(&rect_list) || ret == 0 )
		{
			if( temp_r.r+temp_r.height-1 < max_r && temp_r.c+temp_r.width-1 < max_c)
			{
				rect = malloc(sizeof(RECT));
				*rect = temp_r;
				rect->id = ++id_count;
				list_add_tail(&rect->list, &rect_list);
				return 1;
			}
		}
	}
	else
	{
		if( list_empty(&rect_list) )
		{
			temp_r.r = 0;
			temp_r.c = 0;
			rect = malloc(sizeof(RECT));
			*rect = temp_r;
			rect->id = ++id_count;
			list_add_tail(&rect->list, &rect_list);
			return 1;
		}

		for(j=0; j<max_c-width+1; j++ )
		{
			for(i=0; i<max_r-height+1; i++ )
			{
				temp_r.r = i;
				temp_r.c = j;
				flag = 0;

				list_for_each(temp, &rect_list)
				{
					p = list_entry(temp, RECT, list);
					ret = getIntersection( p, &temp_r );
					if( ret == 1 )
					{
						flag=1;
						break;
					}
				}
				if( flag == 0 )
				{
					rect = malloc(sizeof(RECT));
					*rect = temp_r;
					rect->id = ++id_count;
					list_add_tail(&rect->list, &rect_list);
					return 1;
				}
			}
		}
	}

	return 0;
}

int getItem(int r, int c, char name[], char tag[])
{
	struct list_head *temp;
	RECT *p;

	list_for_each(temp, &rect_list)
	{
		p = list_entry(temp, RECT, list );
		if(  (p->r <= r-1 && r-1 < p->height) &&
		     (p->c <= c-1 && c-1 < p->width) )
		{
			my_strcpy( name, p->name );
			my_strcpy( tag, p->tag );
			return 1;
		}
	}
	return 0;
}

int getArea(char tag[])
{
	int area=0;
	struct list_head *temp;
	RECT *p;

	list_for_each(temp, &rect_list)
	{
		p = list_entry(temp, RECT, list );
		if( my_strcmp(p->tag, tag) == 0 ) 
		{
			area += p->height*p->width;
		}
	}
	return area;
}

int removeItemByName(char name[])
{
	int count=0;
	struct list_head *temp, *n;
	RECT *p;

	list_for_each_safe(temp, n, &rect_list)
	{
		p = list_entry(temp, RECT, list );
		if( my_strcmp(p->name, name) == 0 ) 
		{
			list_del(temp);
			count++;
		}
	}
	return count;
}

int removeItemByTag(char tag[])
{
	int count=0;
	struct list_head *temp, *n;
	RECT *p;

	list_for_each_safe(temp, n, &rect_list)
	{
		p = list_entry(temp, RECT, list );
		if( my_strcmp(p->tag, tag) == 0 ) 
		{
			list_del(temp);
			count++;
		}
	}
	return count;
}

int main()
{
	int ret;
	char name[11];
	char tag[11];
	init(6,6);

	ret = addItem("one", "number", 1, 1, 0, 1, 1);
	printf("ret=%d\n", ret );
	
	ret = addItem("two", "number", 1, 1, 0, 1, 6);
	printf("ret=%d\n", ret );

	ret = addItem("three", "number", 1, 1, 0, 6, 1);
	printf("ret=%d\n", ret );

	ret = addItem("four", "number", 1, 1, 0, 6, 6);
	printf("ret=%d\n", ret );

	ret = getItem(1,1,name, tag );
	printf("ret=%d\n", ret );
	if( ret == 1 ) printf("name=%s, tag=%s\n\n", name, tag );

	ret = getItem(1,2,name, tag );
	printf("ret=%d\n", ret );
	if( ret == 1 ) printf("name=%s, tag=%s\n\n", name, tag );

	ret = getArea("number");
	printf("ret=%d\n", ret );

	ret = getArea("fruit");
	printf("ret=%d\n", ret );

	removeItemByName("apple");
	printf("ret=%d\n", ret );

	removeItemByName("fruit");
	printf("ret=%d\n", ret );

	ret = addItem("apple", "fruit", 3, 3, 1, 5, 6);
	printf("ret=%d\n", ret );

	ret = addItem("kiwi", "fruit", 2, 3, 1, 1, 1);
	printf("ret=%d\n", ret );

	ret = addItem("banana", "fruit", 5, 5, 1, 1, 1);
	printf("ret=%d\n", ret );


	ret = getArea("fruit");
	printf("ret=%d\n", ret );

	ret = getItem(3,3,name, tag );
	printf("ret=%d\n", ret );
	if( ret == 1 ) printf("name=%s, tag=%s\n\n", name, tag );

	ret = removeItemByName("one");
	printf("ret=%d\n", ret );

	//display();

	ret = removeItemByName("five");
	printf("ret=%d\n", ret );

	ret = getArea("number");
	printf("ret=%d\n", ret );

	ret = getItem(1,1,name, tag );
	printf("ret=%d\n", ret );
	if( ret == 1 ) printf("name=%s, tag=%s\n\n", name, tag );

	ret = removeItemByTag("number");
	printf("ret=%d\n", ret );

	ret = getArea("number");
	printf("ret=%d\n", ret );

	ret = getItem(6,1,name, tag );
	printf("ret=%d\n", ret );
	if( ret == 1 ) printf("name=%s, tag=%s\n\n", name, tag );

	ret = removeItemByTag("number");
	printf("ret=%d\n", ret );

	ret = removeItemByTag("fruit");
	printf("ret=%d\n", ret );

	ret = removeItemByTag("fruit");
	printf("ret=%d\n", ret );

	ret = getArea("number");
	printf("ret=%d\n", ret );

	ret = getArea("fruit");
	printf("ret=%d\n", ret );

	ret = getArea("snack");
	printf("ret=%d\n", ret );

	ret = addItem("test", "test", 3, 4, 0, 2, 3);
	printf("ret=%d\n", ret );

	ret = addItem("tast", "test", 1, 1, 0, 3, 4);
	printf("ret=%d\n", ret );

	ret = addItem("tvst", "test", 6, 2, 0, 1, 2);
	printf("ret=%d\n", ret );

	ret = addItem("taest", "test", 2, 2, 0, 6, 6);
	printf("ret=%d\n", ret );

	ret = getArea("test");
	printf("ret=%d\n", ret );

	ret = removeItemByName("test");
	printf("ret=%d\n", ret );

	ret = getArea("test");
	printf("ret=%d\n", ret );

	display();

	return 0;
}











